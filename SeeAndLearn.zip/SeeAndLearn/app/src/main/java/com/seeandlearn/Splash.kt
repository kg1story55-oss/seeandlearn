package com.seeandlearn

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** شاشة البداية: نفس خلفية ولوجو التطبيق، بحركة دخول وتحميل */
@Composable
fun SplashScreen() {
    var started by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { started = true }
    val scale by animateFloatAsState(if (started) 1f else 0.55f, spring(dampingRatio = 0.45f, stiffness = 120f), label = "scale")
    val alpha by animateFloatAsState(if (started) 1f else 0f, tween(600), label = "alpha")
    Box(
        Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFFFFD84D), Color(0xFFFFC400)))),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Image(painterResource(R.drawable.ic_fg), null, Modifier.size(340.dp).scale(scale).alpha(alpha))
            Spacer(Modifier.height(20.dp))
            CircularProgressIndicator(color = Color(0xFF7A62F0), strokeWidth = 5.dp, modifier = Modifier.size(40.dp).alpha(alpha))
            Spacer(Modifier.height(12.dp))
            Text("جاري التحميل...", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF5B3FA0), modifier = Modifier.alpha(alpha))
        }
    }
}
