package com.seeandlearn

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

class SafetyEntry(val time: Long, val source: String, val term: String, val allowed: Boolean, val reason: String)
class TestRow(val label: String, val expectBlock: Boolean, val blocked: Boolean) { val ok: Boolean get() = expectBlock == blocked }

/** فلتر أمان الأطفال: كلمات + تصنيفات ويكيبيديا + فحص الذكاء الاصطناعي + سجل واختبار ذاتي */
object Safety {
    private var prefs: SharedPreferences? = null
    fun init(ctx: Context) { prefs = ctx.getSharedPreferences("safety", 0) }

    // ---- قوائم الكلمات (إنجليزي: كلمات كاملة وبدايات، عربي: بعد التطبيع) ----
    private val mildEn = setOf("alcohol", "beer", "wine", "vodka", "whisky", "whiskey", "cigarette", "cigarettes", "tobacco", "vape", "gambling",
        "casino", "war", "wars", "weapon", "weapons", "gun", "guns", "rifle", "pistol", "shotgun", "grenade", "bomb", "bombs", "explosive",
        "explosives", "firearm", "firearms", "slave", "slavery", "abortion")
    private val enExact = mildEn + setOf("sex", "sexy", "porn", "nude", "nudes", "nudity", "naked", "rape", "raped", "kill", "kills", "killed", "killing",
        "drug", "drugs", "weed", "meth", "lsd", "isis", "nazi", "nazis", "hitler", "suicide", "gore", "nsfw", "penis", "vagina", "boobs", "orgy",
        "murder", "murders", "massacre", "genocide", "torture", "terror", "terrorism", "terrorist", "cocaine", "heroin", "marijuana", "cannabis",
        "opium", "narcotic", "narcotics", "lingerie", "stripper", "brothel", "prostitute", "prostitution", "fetish", "bdsm", "hentai", "condom",
        "condoms", "masturbation", "orgasm", "incest", "pedophile", "pedophilia", "molest", "molestation", "assault", "beheading", "corpse",
        "fuck", "fucking", "shit", "bitch", "asshole", "dick", "cunt", "pussy", "whore", "slut", "bastard")
    private val enPrefix = listOf("sexual", "erotic", "genital", "prostitut", "pedophil", "molest", "masturbat", "porn", "tortur", "massacr", "suicid",
        "terroris", "behead", "cannabi", "narcoti", "methamphet", "gambl", "explosiv", "firearm", "homicid", "fetish")
    private val mildPrefix = setOf("gambl", "explosiv", "firearm")

    private val arMild = setOf("حرب", "سلاح", "اسلحه", "مسدس", "بندقيه", "رشاش", "قنبله", "متفجر", "تفجير", "خمر", "خمور", "نبيذ", "بيره", "كحول",
        "كحوليات", "ويسكي", "فودكا", "سيجاره", "سجائر", "تدخين", "قمار", "مقامره", "كازينو")
    private val arAll = arMild + setOf("جنس", "جنسي", "اباحي", "اباحيه", "عاري", "عاريه", "عري", "اغتصاب", "زنا", "دعاره", "عاهره", "عاهر", "شذوذ",
        "قتل", "ذبح", "جثه", "اغتيال", "مجزره", "ابادة", "اباده", "تعذيب", "انتحار", "ارهاب", "ارهابي", "رصاصه", "مخدر", "مخدرات", "حشيش", "هيروين",
        "كوكايين", "افيون", "بانجو", "ماريجوانا", "شرموط", "شرموطه", "منيوك")
    private val phrases = listOf("dead body", "sex toy", "ابن الكلب")
    private val badCategories = listOf("sexual", "sex ", "erotic", "pornograph", "nudity", "violence", "murder", "massacre", "genocide", "torture",
        "terroris", "war crime", "weapon", "firearm", "explosive", "drug", "narcotic", "alcohol", "tobacco", "smoking", "gambling", "suicide",
        "prostitution", "slavery", "abuse", "nazi", "fetish", "bdsm", "obscen", "adult",
        "جنس", "اباح", "عري", "عنف", "قتل", "مجازر", "تعذيب", "ارهاب", "اسلحه", "مخدر", "كحول", "تدخين", "قمار", "انتحار", "دعاره", "استعباد", "اعتداء", "نازي")

    fun norm(s: String): String = s.lowercase()
        .replace(Regex("[\\u064B-\\u0652\\u0670\\u0640]"), "")
        .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ى', 'ي').replace('ة', 'ه')
        .replace(Regex("[^a-z0-9\\u0621-\\u064A]+"), " ").trim()

    private fun arVariants(t: String): List<String> {
        val out = mutableListOf(t)
        for (p in listOf("وال", "بال", "كال", "فال", "لل", "ال", "و", "ب", "ل", "ف")) if (t.startsWith(p) && t.length > p.length + 1) out.add(t.removePrefix(p))
        return out
    }

    private fun hit(s: String, strict: Boolean): String? {
        val n = norm(s)
        if (n.isEmpty()) return null
        for (p in phrases) if (n.contains(norm(p))) return p
        val enE = if (strict) enExact else enExact - mildEn
        val enP = if (strict) enPrefix else enPrefix.filter { it !in mildPrefix }
        val arE = if (strict) arAll else arAll - arMild
        for (t in n.split(" ").filter { it.isNotBlank() }) {
            if (t in enE) return t
            if (enP.any { t.startsWith(it) }) return t
            if (arVariants(t).any { it in arE }) return t
            // جذور عربية طويلة (4 حروف فأكتر) بتتفحص بالاحتواء علشان تلقط التصريفات
            if (arE.any { it.length >= 4 && t.contains(it) }) return t
        }
        return null
    }

    /** للعناوين والبحث والتصنيفات: الأشد */
    fun hitStrict(s: String): String? = hit(s, true)
    /** لجمل الشرح: بيسمح بكلمات تاريخية/علمية عادية زي سلاح أو حرب */
    fun hitText(s: String): String? = hit(s, false)

    fun hitCategory(cats: List<String>): String? {
        for (c in cats) {
            val n = norm(c.substringAfter(':'))
            val h = badCategories.firstOrNull { n.contains(norm(it)) }
            if (h != null) return c
        }
        return null
    }

    /** ينضّف الشرح: لو أول جملة (التعريف) مش مناسبة يرجّع null (الموضوع كله مرفوض)، غير كده بيشيل الجمل المخالفة بس */
    fun cleanText(text: String): String? {
        val sents = text.split(Regex("(?<=[.!؟?])\\s+")).filter { it.isNotBlank() }
        if (sents.isEmpty()) return text
        if (hitText(sents[0]) != null) return null
        return sents.filter { hitText(it) == null }.joinToString(" ")
    }

    // ---- السجل (على الجهاز بس) ----
    fun log(source: String, term: String, allowed: Boolean, reason: String) {
        val p = prefs ?: return
        val arr = try { JSONArray(p.getString("log", "[]")) } catch (e: Exception) { JSONArray() }
        arr.put(JSONObject().put("t", System.currentTimeMillis()).put("s", source).put("q", term.take(60)).put("a", allowed).put("r", reason))
        val out = JSONArray()
        for (i in maxOf(0, arr.length() - 200) until arr.length()) out.put(arr.get(i))
        p.edit().putString("log", out.toString()).putInt("n_total", p.getInt("n_total", 0) + 1)
            .putInt("n_blocked", p.getInt("n_blocked", 0) + if (allowed) 0 else 1).apply()
    }
    fun total(): Int = prefs?.getInt("n_total", 0) ?: 0
    fun blocked(): Int = prefs?.getInt("n_blocked", 0) ?: 0
    fun recent(n: Int): List<SafetyEntry> {
        val arr = try { JSONArray(prefs?.getString("log", "[]") ?: "[]") } catch (e: Exception) { JSONArray() }
        return (arr.length() - 1 downTo maxOf(0, arr.length() - n)).map {
            val o = arr.getJSONObject(it)
            SafetyEntry(o.optLong("t"), o.optString("s"), o.optString("q"), o.optBoolean("a"), o.optString("r"))
        }
    }

    // ---- اختبار ذاتي: لازم المحظور يتحظر والمناسب يعدّي ----
    fun selfTest(): List<TestRow> {
        val mustBlock = listOf("sex", "porn", "nude photos", "naked", "gun", "cocaine", "heroin", "marijuana", "suicide", "terrorist", "beer", "vodka",
            "casino", "hitler", "murder", "rape", "weapons", "fuck", "how to kill", "dead body", "prostitute", "bomb",
            "اباحي", "جنس", "جنسي", "مخدرات", "حشيش", "سلاح", "قتل", "انتحار", "الحرب", "خمر", "سجائر", "قمار", "ارهاب", "عاري", "اغتصاب", "الأسلحة", "تدخين")
        val mustAllow = Catalog.values.flatten().flatMap { listOf(it.first, it.second) } +
            listOf("Essex", "Sussex", "Killer whale", "Tasmanian devil", "Sperm whale", "Warthog", "Pencil", "Giraffe", "Seaweed", "Methane", "Glass",
                "قلم رصاص", "حرباء", "زرافة", "الأسد", "مدرسة", "كتاب", "ماما", "بابا", "لعبة", "ملعقة")
        return mustBlock.map { TestRow("🚫 $it", true, hitStrict(it) != null) } + mustAllow.map { TestRow("✅ $it", false, hitStrict(it) != null) }
    }
}
