package com.seeandlearn

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

private class RaceCat(val emoji: String, val name: String, val en: String) { val label: String get() = "$emoji $name" }

private val RaceCats = listOf(
    RaceCat("🔴", "حاجات لونها أحمر", "an object that is mainly red in color"),
    RaceCat("🔵", "حاجات لونها أزرق", "an object that is mainly blue in color"),
    RaceCat("🟢", "حاجات لونها أخضر", "an object that is mainly green in color"),
    RaceCat("🟡", "حاجات لونها أصفر", "an object that is mainly yellow in color"),
    RaceCat("🍳", "أدوات المطبخ", "a kitchen utensil, tool or appliance"),
    RaceCat("✏️", "أدوات المدرسة", "a school supply such as a pen, pencil, notebook, ruler or school bag"),
    RaceCat("🍎", "فواكه وخضار", "a fruit or a vegetable"),
    RaceCat("🐾", "حيوانات (حقيقية أو لعب)", "an animal, a toy animal or a picture of an animal"),
    RaceCat("🪑", "أثاث البيت", "a piece of home furniture"),
    RaceCat("🧹", "أدوات النظافة", "a cleaning tool or cleaning product")
)

private data class RaceItem(val id: Int, val thumb: Bitmap, val status: Int, val label: String)   // status: 0 بيتفحص، 1 صح، 2 غلط

@Composable
private fun RaceThumb(it: RaceItem, size: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Image(it.thumb.asImageBitmap(), null, Modifier.size(size.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop)
        Text(when (it.status) { 0 -> "⏳"; 1 -> "✅"; else -> "❌" }, fontSize = 18.sp)
    }
}

/** سباق الكاميرا: ٦٠ ثانية وصوّر أكبر عدد من نوع معيّن، والتطبيق بيتأكد من كل صورة */
@Composable
fun RaceGame() {
    val scope = rememberCoroutineScope()
    var phase by remember { mutableStateOf(0) }            // 0 اختيار، 1 جاري، 2 نتيجة
    var cat by remember { mutableStateOf(RaceCats[0]) }
    var endAt by remember { mutableStateOf(0L) }
    var timeLeft by remember { mutableStateOf(60) }
    val items = remember { mutableStateListOf<RaceItem>() }
    val found = remember { mutableSetOf<String>() }
    val mutex = remember { Mutex() }
    var nextId by remember { mutableStateOf(0) }
    var recorded by remember { mutableStateOf(false) }
    var bonus by remember { mutableStateOf(0) }
    val score = items.count { it.status == 1 }
    val pending = items.count { it.status == 0 }

    LaunchedEffect(phase) {
        if (phase == 1) {
            while (true) {
                val left = ((endAt - System.currentTimeMillis() + 999) / 1000).toInt()
                timeLeft = left.coerceIn(0, 60)
                if (left <= 0) break
                delay(200)
            }
            phase = 2
            Sfx.speak("خلص الوقت!", true)
        }
    }
    LaunchedEffect(phase, pending) {
        if (phase == 2 && pending == 0 && !recorded) {
            recorded = true
            Store.setRaceBest(score)
            bonus = if (score >= 8) 5 else if (score >= 5) 3 else 0
            if (bonus > 0) Store.addStars(bonus)
        }
    }

    fun start(c: RaceCat) {
        cat = c; items.clear(); found.clear(); recorded = false; bonus = 0
        endAt = System.currentTimeMillis() + 60_000; timeLeft = 60; phase = 1
        Sfx.speak("يلا! صوّر ${c.name}", true)
    }

    fun submit(b: Bitmap) {
        val id = nextId++
        items.add(0, RaceItem(id, b, 0, ""))
        val desc = cat.en
        scope.launch {
            mutex.withLock {
                var status = 2
                var label = "مش من النوع ده"
                val r = if (BuildConfig.GEMINI_KEY.isBlank()) MResult(null, null, "no key") else Gemini.checkMission(b, BuildConfig.GEMINI_KEY, desc)
                val nm = r.name
                if (nm.equals("UNSAFE", ignoreCase = true)) {
                    Safety.log("race", "(صورة)", false, "AI: صورة غير مناسبة")
                    label = "صورة غير مناسبة"
                } else if (r.ok == true && nm != null) {
                    val key = nm.lowercase()
                    if (key in found) {
                        label = "اتصوّرت قبل كده"
                    } else {
                        val inf = Wiki.info(nm)
                        if (inf?.blockedReason != null) {
                            label = "غير مناسبة"
                        } else {
                            found.add(key); status = 1
                            label = inf?.title ?: nm
                            inf?.let { Store.saveWord(it, b) }
                            Store.correct("race")
                        }
                    }
                } else if (r.ok == null) {
                    label = "مقدرتش أتأكد"
                }
                val idx = items.indexOfFirst { it.id == id }
                if (idx >= 0) items[idx] = items[idx].copy(status = status, label = label)
                if (status == 1) Sfx.ding() else Sfx.buzz()
            }
        }
    }

    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { b ->
        if (b != null && phase != 0 && System.currentTimeMillis() <= endAt + 6000) submit(b)
    }

    Column(Modifier.verticalScroll(rememberScrollState())) {
        when (phase) {
            0 -> {
                Banner("📸 سباق الكاميرا", "٦٠ ثانية   •   أفضل نتيجة: ${Store.raceBest()}", Teal, Pink)
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("اختار نوع الحاجات، وبعدها صوّر أكبر عدد منها في ٦٠ ثانية! 🏃", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Purple)
                    RaceCats.chunked(2).forEachIndexed { r, row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            row.forEachIndexed { c, rc ->
                                Box(Modifier.weight(1f).height(96.dp).clip(RoundedCornerShape(22.dp)).background(Palette[(r * 2 + c) % Palette.size])
                                    .clickable { start(rc) }.padding(10.dp), contentAlignment = Alignment.Center) {
                                    Text(rc.label, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                                }
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
            1 -> {
                Banner("📸 ${cat.label}", "✅ $score صح   •   مستوى ${Store.level("race")}", Teal, Pink)
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$timeLeft", fontSize = 84.sp, fontWeight = FontWeight.Bold, color = if (timeLeft <= 10) Red else Purple)
                    Box(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(7.dp)).background(Color(0xFFE0E0E0))) {
                        Box(Modifier.fillMaxWidth(timeLeft / 60f).fillMaxHeight().background(if (timeLeft <= 10) Red else Green))
                    }
                    BigBtn("📷 صوّر!", Pink, Modifier.fillMaxWidth()) { camera.launch(null) }
                    if (items.isNotEmpty()) {
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items.forEach { RaceThumb(it, 76) }
                        }
                    }
                    TextButton({ phase = 2; Sfx.speak("خلّصنا!", true) }) { Text("🏁 خلّصت قبل الوقت") }
                }
            }
            else -> {
                Banner("🏁 خلص الوقت!", "${cat.label}", Orange, Pink)
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$score", fontSize = 80.sp, fontWeight = FontWeight.Bold, color = Purple)
                    Text("صورة صح", fontSize = 20.sp)
                    if (pending > 0) Text("⏳ بتأكد من $pending صورة...", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Orange)
                    else {
                        Text("أفضل نتيجة: ${Store.raceBest()}", fontSize = 16.sp, color = Color.Gray)
                        if (bonus > 0) Text("🎁 مكافأة +$bonus نجوم!", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Green)
                    }
                    items.forEach {
                        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                RaceThumb(it, 56)
                                Text(if (it.status == 0) "بيتفحص..." else it.label, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                                    color = if (it.status == 1) Color(0xFF2E9E5B) else Color(0xFF555555))
                            }
                        }
                    }
                    if (pending == 0) BigBtn("🔄 العب تاني", Purple, Modifier.fillMaxWidth()) { phase = 0 }
                }
            }
        }
    }
}
