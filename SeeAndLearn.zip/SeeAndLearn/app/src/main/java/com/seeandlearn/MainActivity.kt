package com.seeandlearn

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

val Pink = Color(0xFFFF6B9D); val Orange = Color(0xFFFF9F43); val Green = Color(0xFF1DD1A1); val Blue = Color(0xFF54A0FF)
val Purple = Color(0xFF8E7CFF); val Red = Color(0xFFFF6B6B); val Teal = Color(0xFF22B8CF); val Yellow = Color(0xFFFECA57)
val Cream = Color(0xFFFFF8E7)
val Palette = listOf(Pink, Orange, Green, Blue, Purple, Red, Teal, Yellow)

class MainActivity : ComponentActivity() {
    override fun onPause() { super.onPause(); Music.pause() }
    override fun onResume() { super.onResume(); Music.resume() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Sfx.init(applicationContext)
        Store.init(applicationContext)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = lightColorScheme(primary = Purple, secondary = Pink, background = Cream, surface = Color.White)) { App() }
            }
        }
    }
}

// ---------- مكوّنات مشتركة ----------
@Composable
fun Banner(title: String, sub: String, c1: Color, c2: Color) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
        .background(Brush.horizontalGradient(listOf(c1, c2))).padding(horizontal = 20.dp, vertical = 18.dp)) {
        Column {
            Text(title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(sub, color = Color.White.copy(alpha = 0.92f), fontSize = 15.sp)
        }
    }
}

@Composable
fun BigBtn(text: String, color: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(onClick, modifier.height(58.dp), shape = RoundedCornerShape(22.dp), colors = ButtonDefaults.buttonColors(containerColor = color)) {
        Text(text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun Chip(text: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(20.dp)).background(if (selected) color else color.copy(alpha = 0.22f))
        .clickable { onClick() }.padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(text, color = if (selected) Color.White else Color(0xFF333333), fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
fun WikiImage(url: String?, modifier: Modifier, scale: ContentScale = ContentScale.Fit) {
    val ctx = LocalContext.current
    AsyncImage(
        model = ImageRequest.Builder(ctx).data(url).addHeader("User-Agent", "SeeAndLearn/1.0 (educational app)").crossfade(true).build(),
        contentDescription = null, modifier = modifier, contentScale = scale
    )
}

// ---------- التطبيق ----------
@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("prefs", 0) }
    var tab by remember { mutableStateOf(0) }
    var open by remember { mutableStateOf<String?>(null) }
    var cat by remember { mutableStateOf<String?>(null) }
    var topic by remember { mutableStateOf("") }
    var more by remember { mutableStateOf(0) }
    var name by remember { mutableStateOf(prefs.getString("name", "") ?: "") }
    var editName by remember { mutableStateOf(false) }
    var draftName by remember { mutableStateOf(name) }
    var music by remember { mutableStateOf(prefs.getBoolean("music", true)) }
    LaunchedEffect(name) { Sfx.name = name }
    LaunchedEffect(music) { Music.set(ctx, music); prefs.edit().putBoolean("music", music).apply() }
    BackHandler(enabled = tab == 4 && more != 0) { if (more == 1 && open != null) open = null else if (more == 1 && cat != null) cat = null else more = 0 }
    if (name.isBlank() || editName) {
        AlertDialog(
            onDismissRequest = { if (name.isNotBlank()) editName = false },
            title = { Text("اسمك إيه يا بطل؟ 🌟", fontWeight = FontWeight.Bold) },
            text = { OutlinedTextField(draftName, { draftName = it }, singleLine = true, label = { Text("اكتب اسمك") }) },
            confirmButton = {
                TextButton({ if (draftName.isNotBlank()) { name = draftName.trim(); prefs.edit().putString("name", name).apply(); editName = false } }) { Text("يلا نبدأ 🚀", fontSize = 18.sp) }
            }
        )
    }
    val tabs = listOf("📷" to "صوّر", "🎯" to "مهام", "🎮" to "ألعاب", "📒" to "ألبومي", "⋯" to "المزيد")
    val tabColors = listOf(Orange, Teal, Pink, Purple, Green)
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFFFF176), Color(0xFFFFB3D9), Color(0xFF9BE7FF))))) {
        Text("⭐", fontSize = 60.sp, modifier = Modifier.align(Alignment.TopStart).padding(start = 8.dp, top = 120.dp).alpha(0.5f))
        Text("🎈", fontSize = 70.sp, modifier = Modifier.align(Alignment.CenterEnd).alpha(0.4f))
        Text("🌈", fontSize = 80.sp, modifier = Modifier.align(Alignment.BottomStart).padding(bottom = 90.dp).alpha(0.4f))
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                Row(Modifier.fillMaxWidth().background(Color.White.copy(alpha = 0.85f)).padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("أهلًا يا $name 👋 ✏️", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Purple,
                        modifier = Modifier.clickable { draftName = name; editName = true })
                    Text((if (Sfx.loading.value) "⏳ " else "") + "⭐ ${Store.stars.value}", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Orange)
                    Text(if (music) "🎵" else "🔇", fontSize = 30.sp, modifier = Modifier.clickable { music = !music })
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White.copy(alpha = 0.92f)) {
                    tabs.forEachIndexed { i, (ic, t) ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i },
                            icon = { Text(ic, fontSize = 26.sp) }, label = { Text(if (i == 3 && Store.dueWords().isNotEmpty()) "$t 🔴" else t, fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                            colors = NavigationBarItemDefaults.colors(indicatorColor = tabColors[i].copy(alpha = 0.3f)))
                    }
                }
            }
        ) { p ->
            Box(Modifier.padding(p).fillMaxSize()) {
                when (tab) {
                    0 -> ScanScreen { topic = it }
                    1 -> MissionsScreen()
                    2 -> GamesHub()
                    3 -> AlbumScreen()
                    4 -> MoreScreen(more, { more = it }, cat, open, { cat = it }, { open = it }, topic) { topic = it }
                }
            }
        }
    }
}

/** بطاقة معلومات: صورة + ملخص + رابط المصدر الموثّق */
@Composable
fun InfoPanel(term: String, onTopic: (String) -> Unit, reload: Int = 0, onLoaded: (Info) -> Unit = {}) {
    var info by remember(term, reload) { mutableStateOf<Info?>(null) }
    var loading by remember(term, reload) { mutableStateOf(true) }
    val ctx = LocalContext.current
    LaunchedEffect(term, reload) { loading = true; info = Wiki.info(term); loading = false; info?.let { onTopic(it.title); onLoaded(it) } }
    if (loading) { Box(Modifier.fillMaxWidth().padding(24.dp), Alignment.Center) { CircularProgressIndicator(color = Pink) }; return }
    val i = info
    if (i == null) { Text("😅 ملقتش معلومات موثّقة عن \"$term\". جرّب اسم تاني."); return }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(6.dp)) {
        Column {
            Box(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Pink, Orange))).padding(16.dp)) {
                Text(i.title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                i.image?.let { WikiImage(it, Modifier.fillMaxWidth().heightIn(max = 280.dp).clip(RoundedCornerShape(20.dp))) }
                Text(i.text, fontSize = 17.sp, lineHeight = 26.sp)
                if (i.enTitle.isNotBlank() && i.lang == "ar") {
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Blue.copy(alpha = 0.15f))) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("🇬🇧 بالإنجليزي", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(i.enTitle, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Purple)
                                BigBtn("🔊", Blue) { Sfx.speakEn(i.enTitle) }
                            }
                            val en = firstSentences(i.enText, 2)
                            if (en.isNotBlank()) { Text(en, fontSize = 15.sp); TextButton({ Sfx.speakEn(en) }) { Text("🔊 اسمع الشرح بالإنجليزي") } }
                        }
                    }
                }
                Box(Modifier.clip(RoundedCornerShape(14.dp)).background(Yellow.copy(alpha = 0.3f)).padding(10.dp)) {
                    Text("📖 المصدر: ويكيبيديا (${if (i.lang == "ar") "العربية" else "الإنجليزية"})", fontSize = 14.sp)
                }
                BigBtn(if (Sfx.loading.value) "⏳ بحمّل الصوت..." else "🔊 اسمعني", Green, Modifier.fillMaxWidth()) { Sfx.speak(i.text.take(350)) }
            }
        }
    }
}

val Generic = setOf("Mammal", "Animal", "Wildlife", "Fauna", "Terrestrial animal", "Vertebrate", "Organism", "Plant", "Natural material",
    "Photograph", "Nature", "Event", "Snapshot", "Recreation", "Fun", "Pattern", "Space", "Room", "Close-up", "Macro photography", "Organ", "Safari", "Sky", "Toy", "Cloud", "Fur", "Whiskers", "Snout", "Neck", "Horn", "Head", "Tourism", "Landscape", "Tree", "Grass", "Adventure", "Vehicle", "Leisure")

@Composable
fun ScanScreen(onTopic: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var uri by remember { mutableStateOf<Uri?>(null) }
    var chosen by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }

    var lastBmp by remember { mutableStateOf<Bitmap?>(null) }
    var scanId by remember { mutableStateOf(0) }
    var photoMode by remember { mutableStateOf(false) }
    fun analyze(full: Bitmap) {
        lastBmp = full; photoMode = true; busy = true; chosen = null; note = null
        scope.launch {
            if (BuildConfig.GEMINI_KEY.isBlank()) {
                note = "⚠️ مفتاح الذكاء الاصطناعي مش موجود في النسخة دي."
            } else {
                val r = Gemini.identify(full, BuildConfig.GEMINI_KEY)
                chosen = r.title; scanId++
                if (r.title == null) note = "😕 معرفتش أوصل للذكاء الاصطناعي دلوقتي، اضغطي \"حاولي تاني\".\n(السبب: ${r.error})"
            }
            busy = false
        }
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) {
        it?.let { b -> bmp = b; uri = null; analyze(b) }
    }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        it?.let { u -> val b = loadBitmap(ctx, u); uri = u; bmp = null; if (b != null) analyze(b) }
    }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Banner("لقطة ومعرفة 🌈", "صوّر أي حاجة وأنا أقولك كل حاجة عنها!", Orange, Pink)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BigBtn("📷 كاميرا", Orange, Modifier.weight(1f)) { camera.launch(null) }
                BigBtn("🖼️ من الجهاز", Blue, Modifier.weight(1f)) { gallery.launch("image/*") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(query, { query = it }, Modifier.weight(1f).background(Color.White.copy(alpha = 0.8f), RoundedCornerShape(18.dp)),
                    label = { Text("أو اكتب اسم أي حاجة") }, singleLine = true, shape = RoundedCornerShape(18.dp))
                BigBtn("🔎", Purple) { if (query.isNotBlank()) { photoMode = false; chosen = "ar:" + query.trim(); note = null; scanId++ } }
            }
            if (bmp == null && uri == null) {
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(24.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🦉", fontSize = 72.sp)
                        Text("أنا البومة الذكية!", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Purple)
                        Text("وجّه الكاميرا على حيوان، فاكهة، شجرة، أداة... وهعرّفك عليها", textAlign = TextAlign.Center, fontSize = 16.sp)
                        Spacer(Modifier.height(10.dp))
                        Text("🐶 🍎 🌳 🐠 🦋 ✏️ 🍳 🎡", fontSize = 30.sp)
                    }
                }
            }
            bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxWidth().heightIn(max = 280.dp).clip(RoundedCornerShape(24.dp))) }
            uri?.let { AsyncImage(it, null, Modifier.fillMaxWidth().heightIn(max = 280.dp).clip(RoundedCornerShape(24.dp))) }
            if (busy) Text("🔍 بفكّر...", fontSize = 22.sp, color = Purple, fontWeight = FontWeight.Bold)
            note?.let { Text(it, fontSize = 14.sp, color = Color(0xFF555555)) }
            if (!busy && chosen == null && lastBmp != null && note != null) BigBtn("🔄 حاولي تاني", Purple, Modifier.fillMaxWidth()) { analyze(lastBmp!!) }
            chosen?.let {
                InfoPanel(it, onTopic, scanId) { info ->
                    if (photoMode) {
                        val isNew = Store.saveWord(info, lastBmp)
                        if (isNew) { Store.addStars(1); Sfx.speak("كلمة جديدة يا ${Sfx.name}! ${info.title}", true) } else Sfx.speak(info.title)
                    } else Sfx.speak(info.title)
                }
            }
        }
    }
}

@Composable
fun BrowseScreen(cat: String?, open: String?, setCat: (String?) -> Unit, setOpen: (String?) -> Unit, onTopic: (String) -> Unit) {
    val cats = Catalog.keys.toList()
    when {
        open != null -> Column(Modifier.fillMaxSize()) {
            Banner(cat?.substringAfter(" ") ?: "تفاصيل", "معلومات من مصادر موثّقة", Green, Teal)
            Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
                TextButton(onClick = { setOpen(null) }) { Text("➡️ رجوع", fontSize = 18.sp) }
                InfoPanel(open, onTopic)
            }
        }
        cat == null -> Column(Modifier.fillMaxSize()) {
            Banner("تصفّح العالم 🌍", "اختار فئة واكتشف", Green, Teal)
            LazyVerticalGrid(GridCells.Fixed(2), contentPadding = PaddingValues(14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(cats) { c ->
                    val color = Palette[cats.indexOf(c) % Palette.size]
                    Box(Modifier.aspectRatio(1.05f).clip(RoundedCornerShape(26.dp))
                        .background(Brush.verticalGradient(listOf(color, color.copy(alpha = 0.65f)))).clickable { setCat(c) },
                        contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(c.substringBefore(" "), fontSize = 52.sp)
                            Text(c.substringAfter(" "), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        else -> Column(Modifier.fillMaxSize()) {
            val color = Palette[cats.indexOf(cat).coerceAtLeast(0) % Palette.size]
            Banner(cat, "اضغط على أي صورة", color, color.copy(alpha = 0.7f))
            TextButton(onClick = { setCat(null) }, modifier = Modifier.padding(horizontal = 8.dp)) { Text("➡️ كل الفئات", fontSize = 16.sp) }
            LazyVerticalGrid(GridCells.Fixed(2), contentPadding = PaddingValues(14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(Catalog[cat].orEmpty()) { (en, ar) ->
                    val thumb by produceState<String?>(null, en) { value = Wiki.thumb(en) }
                    Card(Modifier.clickable { setOpen(en) }, shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(4.dp)) {
                        Column {
                            Box(Modifier.fillMaxWidth().height(110.dp).background(color.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
                                if (thumb != null) WikiImage(thumb, Modifier.fillMaxSize(), ContentScale.Crop) else Text(cat.substringBefore(" "), fontSize = 36.sp)
                            }
                            Column(Modifier.padding(10.dp)) {
                                Text(ar, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

private data class Q(val correct: Pair<String, String>, val opts: List<Pair<String, String>>)

/** لعبة: إيه ده؟ صورة من ويكيبيديا + 4 اختيارات من نفس الفئة */
@Composable
fun QuizScreen() {
    var round by remember { mutableStateOf(0) }
    var score by remember { mutableStateOf(0) }
    var q by remember { mutableStateOf<Q?>(null) }
    var img by remember { mutableStateOf<String?>(null) }
    var answered by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(round) {
        answered = null; img = null
        val group = Catalog.values.toList().random()
        val correct = group.random()
        q = Q(correct, (group.filter { it != correct }.shuffled().take(3) + correct).shuffled())
        img = Wiki.thumb(correct.first)
    }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Banner("🎮 إيه ده؟", "⭐ النقاط: $score   •   السؤال ${round + 1}", Pink, Purple)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(Modifier.fillMaxWidth().height(250.dp), shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Box(Modifier.fillMaxSize(), Alignment.Center) {
                    if (img != null) WikiImage(img, Modifier.fillMaxSize().padding(6.dp).clip(RoundedCornerShape(22.dp)), ContentScale.Fit)
                    else Text("🤔", fontSize = 80.sp)
                }
            }
            q?.let { cur ->
                cur.opts.forEachIndexed { i, o ->
                    val base = Palette[i % Palette.size]
                    val c = when {
                        answered == null -> base
                        o == cur.correct -> Color(0xFF2E9E5B)
                        o.first == answered -> Color(0xFFD63031)
                        else -> base.copy(alpha = 0.35f)
                    }
                    Button({ if (answered == null) { answered = o.first; if (o == cur.correct) { score++; Sfx.correct() } else Sfx.wrong() } }, Modifier.fillMaxWidth().height(60.dp),
                        shape = RoundedCornerShape(22.dp), colors = ButtonDefaults.buttonColors(containerColor = c)) {
                        Text(o.second, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                }
                if (answered != null) {
                    val ok = answered == cur.correct.first
                    Text(if (ok) "🎉 برافو! إجابة صح" else "😅 الإجابة الصح: ${cur.correct.second}", fontSize = 20.sp, fontWeight = FontWeight.Bold,
                        color = if (ok) Color(0xFF2E9E5B) else Color(0xFFD63031), modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                    BigBtn("السؤال اللي بعده ⏭️", Purple, Modifier.fillMaxWidth()) { round++ }
                }
            }
        }
    }
}
