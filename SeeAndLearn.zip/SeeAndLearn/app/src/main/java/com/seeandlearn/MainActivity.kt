package com.seeandlearn

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme { App() }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    var tab by remember { mutableStateOf(0) }
    var open by remember { mutableStateOf<String?>(null) }   // موضوع مفتوح من التصفح
    var topic by remember { mutableStateOf("") }              // آخر موضوع للتعلّم
    val tabs = listOf("📷" to "صوّر", "📚" to "تصفّح", "🎮" to "ألعاب", "💡" to "تعلّم")
    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, (ic, t) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i; open = null },
                        icon = { Text(ic) }, label = { Text(t) })
                }
            }
        }
    ) { p ->
        Box(Modifier.padding(p).fillMaxSize()) {
            if (open != null && tab == 1) {
                Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
                    TextButton(onClick = { open = null }) { Text("← رجوع") }
                    InfoPanel(open!!) { topic = it }
                }
            } else when (tab) {
                0 -> ScanScreen { topic = it }
                1 -> BrowseScreen { open = it }
                2 -> QuizScreen()
                3 -> LearnScreen(topic) { topic = it }
            }
        }
    }
}

/** بطاقة معلومات: صورة + ملخص + رابط المصدر الموثّق */
@Composable
fun InfoPanel(term: String, onTopic: (String) -> Unit) {
    var info by remember(term) { mutableStateOf<Info?>(null) }
    var loading by remember(term) { mutableStateOf(true) }
    val ctx = LocalContext.current
    LaunchedEffect(term) { loading = true; info = Wiki.info(term); loading = false; info?.let { onTopic(it.title) } }
    if (loading) { CircularProgressIndicator(); return }
    val i = info
    if (i == null) { Text("ملقتش معلومات موثّقة عن \"$term\". جرّب اسم تاني."); return }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(i.title, style = MaterialTheme.typography.headlineSmall)
            i.image?.let { AsyncImage(it, i.title, Modifier.fillMaxWidth().heightIn(max = 260.dp)) }
            Text(i.text)
            Text("المصدر: ويكيبيديا (${if (i.lang == "ar") "العربية" else "الإنجليزية"})", style = MaterialTheme.typography.labelMedium)
            Button(onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(i.url))) }) { Text("اقرأ المقال الكامل") }
        }
    }
}

@Composable
fun ScanScreen(onTopic: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var uri by remember { mutableStateOf<Uri?>(null) }
    var labels by remember { mutableStateOf<List<String>>(emptyList()) }
    var chosen by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    fun analyze(img: InputImage) {
        busy = true; labels = emptyList(); chosen = null
        scope.launch {
            try {
                val res = ImageLabeling.getClient(ImageLabelerOptions.Builder().setConfidenceThreshold(0.5f).build()).process(img).await()
                labels = res.sortedByDescending { it.confidence }.take(6).map { it.text }
                chosen = labels.firstOrNull()
            } catch (e: Exception) { labels = emptyList() }
            busy = false
        }
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) {
        it?.let { b -> bmp = b; uri = null; analyze(InputImage.fromBitmap(b, 0)) }
    }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        it?.let { u -> uri = u; bmp = null; analyze(InputImage.fromFilePath(ctx, u)) }
    }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("صوّر أي حاجة حواليك 👀", style = MaterialTheme.typography.headlineSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ camera.launch(null) }) { Text("📷 كاميرا") }
            OutlinedButton({ gallery.launch("image/*") }) { Text("🖼️ من الجهاز") }
        }
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxWidth().heightIn(max = 260.dp)) }
        uri?.let { AsyncImage(it, null, Modifier.fillMaxWidth().heightIn(max = 260.dp)) }
        if (busy) CircularProgressIndicator()
        if (labels.isNotEmpty()) {
            Text("ممكن يكون:")
            Row(Modifier.verticalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                labels.forEach { l -> FilterChip(selected = chosen == l, onClick = { chosen = l }, label = { Text(l) }) }
            }
        } else if (!busy && (bmp != null || uri != null)) Text("مقدرتش أتعرف على الصورة، جرّب صورة أوضح.")
        chosen?.let { InfoPanel(it, onTopic) }
    }
}

@Composable
fun BrowseScreen(onOpen: (String) -> Unit) {
    var cat by remember { mutableStateOf(Catalog.keys.first()) }
    Column(Modifier.padding(16.dp)) {
        Row(Modifier.verticalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Catalog.keys.forEach { FilterChip(selected = cat == it, onClick = { cat = it }, label = { Text(it) }) }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 8.dp)) {
            items(Catalog[cat].orEmpty()) { (en, ar) ->
                ElevatedCard(onClick = { onOpen(en) }, Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), Arrangement.SpaceBetween) { Text(ar); Text(en, style = MaterialTheme.typography.labelMedium) }
                }
            }
        }
    }
}

/** لعبة: إيه ده؟ صورة من ويكيبيديا + 4 اختيارات */
@Composable
fun QuizScreen() {
    val all = remember { Catalog.values.flatten() }
    var round by remember { mutableStateOf(0) }
    var score by remember { mutableStateOf(0) }
    var q by remember { mutableStateOf<Pair<Pair<String, String>, List<Pair<String, String>>>?>(null) }
    var img by remember { mutableStateOf<String?>(null) }
    var answered by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(round) {
        answered = null; img = null
        val correct = all.random()
        q = correct to (all.filter { it != correct }.shuffled().take(3) + correct).shuffled()
        img = Wiki.info(correct.first)?.image
    }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("🎮 إيه ده؟  —  النقاط: $score", style = MaterialTheme.typography.titleLarge)
        if (img != null) AsyncImage(img, null, Modifier.fillMaxWidth().heightIn(max = 240.dp)) else CircularProgressIndicator()
        q?.let { (correct, opts) ->
            opts.forEach { o ->
                val color = when { answered == null -> ButtonDefaults.buttonColors(); o == correct -> ButtonDefaults.buttonColors(containerColor = androidx.compose.ui.graphics.Color(0xFF2E7D32))
                    o.first == answered -> ButtonDefaults.buttonColors(containerColor = androidx.compose.ui.graphics.Color(0xFFC62828)); else -> ButtonDefaults.buttonColors() }
                Button({ if (answered == null) { answered = o.first; if (o == correct) score++ } }, Modifier.fillMaxWidth(), colors = color) { Text(o.second) }
            }
            if (answered != null) Button({ round++ }, Modifier.fillMaxWidth()) { Text("السؤال اللي بعده ⏭️") }
        }
    }
}

@Composable
fun LearnScreen(topic: String, setTopic: (String) -> Unit) {
    var sel by remember { mutableStateOf(0) }
    val ideas = remember { mutableStateListOf<String>() }
    var draft by remember { mutableStateOf("") }
    val names = listOf("🧠 عصف ذهني", "📋 KWL", "🗺️ خريطة ذهنية", "👶 فاينمان", "📖 SQ3R", "🔁 تكرار متباعد")
    val prompts = listOf("ماذا؟", "لماذا؟", "كيف؟", "أين؟", "متى؟", "ماذا لو؟", "مين المستفيد؟", "إيه الشبه والاختلاف؟")
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(topic, setTopic, label = { Text("الموضوع (بيتملي من آخر حاجة صورتها)") }, modifier = Modifier.fillMaxWidth())
        Row(Modifier.verticalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            names.forEachIndexed { i, n -> FilterChip(selected = sel == i, onClick = { sel = i }, label = { Text(n) }) }
        }
        when (sel) {
            0 -> {
                Text("اكتب أكبر عدد أفكار عن \"$topic\" من غير ما تحكم عليها. اسأل نفسك:")
                Text(prompts.joinToString("  •  "))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(draft, { draft = it }, Modifier.weight(1f), label = { Text("فكرة") })
                    Button({ if (draft.isNotBlank()) { ideas.add(draft); draft = "" } }) { Text("أضف") }
                }
                ideas.forEachIndexed { i, s -> Text("${i + 1}. $s") }
            }
            1 -> { Text("K — أنا عارف إيه عن \"$topic\"؟"); OutlinedTextField("", {}, Modifier.fillMaxWidth())
                Text("W — عايز أعرف إيه؟"); OutlinedTextField("", {}, Modifier.fillMaxWidth())
                Text("L — اتعلمت إيه؟"); OutlinedTextField("", {}, Modifier.fillMaxWidth()) }
            2 -> Text("اكتب \"$topic\" في النص، وفرّع منه: الشكل • المكان • الفايدة • الأنواع • معلومة غريبة. ارسم الفروع بألوان مختلفة.")
            3 -> Text("اشرح \"$topic\" كأنك بتشرحه لطفل عنده 8 سنين. لو اتلخبطت في نقطة، ارجع اقرأ عنها وبسّطها أكتر.")
            4 -> Text("S اسمح بنظرة سريعة • Q حوّل العناوين لأسئلة • R اقرأ • R اسرد من ذاكرتك • R راجع.")
            5 -> Text("راجع \"$topic\" بعد يوم، ثم 3 أيام، ثم أسبوع، ثم شهر. كل مراجعة بتثبّت المعلومة أكتر.")
        }
    }
}
