package com.seeandlearn

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** كتالوج (English title على ويكيبيديا to عربي). الصور والمعلومات بتتجلب لايف من ويكيبيديا. */
val Catalog: Map<String, List<Pair<String, String>>> = linkedMapOf(
    "🐾 حيوانات" to listOf("Lion" to "أسد", "Elephant" to "فيل", "Giraffe" to "زرافة", "Camel" to "جمل", "Horse" to "حصان", "Cow" to "بقرة", "Sheep" to "خروف", "Cat" to "قطة", "Dog" to "كلب", "Rabbit" to "أرنب", "Monkey" to "قرد", "Zebra" to "حمار وحشي", "Tiger" to "نمر", "Bear" to "دب", "Fox" to "ثعلب", "Crocodile" to "تمساح"),
    "🦅 طيور" to listOf("Eagle" to "نسر", "Parrot" to "ببغاء", "Owl" to "بومة", "Duck" to "بطة", "Chicken" to "دجاجة", "Peacock" to "طاووس", "Penguin" to "بطريق", "Ostrich" to "نعامة", "Pigeon" to "حمامة", "Flamingo" to "فلامنجو", "Swan" to "بجعة", "Falcon" to "صقر"),
    "🐞 حشرات" to listOf("Bee" to "نحلة", "Butterfly" to "فراشة", "Ant" to "نملة", "Ladybug" to "دعسوقة", "Dragonfly" to "يعسوب", "Grasshopper" to "جرادة", "Mosquito" to "بعوضة", "Spider" to "عنكبوت", "Scorpion" to "عقرب", "Cricket (insect)" to "صرصور الليل"),
    "🐠 البحر" to listOf("Shark" to "قرش", "Dolphin" to "دلفين", "Whale" to "حوت", "Octopus" to "أخطبوط", "Jellyfish" to "قنديل البحر", "Seahorse" to "حصان البحر", "Starfish" to "نجم البحر", "Crab" to "سلطعون", "Sea turtle" to "سلحفاة بحرية", "Clownfish" to "سمكة المهرج", "Coral" to "مرجان", "Seaweed" to "أعشاب بحرية"),
    "🍎 فواكه" to listOf("Apple" to "تفاح", "Banana" to "موز", "Orange (fruit)" to "برتقال", "Grape" to "عنب", "Strawberry" to "فراولة", "Watermelon" to "بطيخ", "Mango" to "مانجو", "Pomegranate" to "رمان", "Fig" to "تين", "Pineapple" to "أناناس", "Peach" to "خوخ", "Lemon" to "ليمون"),
    "🥕 خضروات" to listOf("Tomato" to "طماطم", "Cucumber" to "خيار", "Carrot" to "جزر", "Potato" to "بطاطس", "Onion" to "بصل", "Garlic" to "ثوم", "Eggplant" to "باذنجان", "Broccoli" to "بروكلي", "Lettuce" to "خس", "Pumpkin" to "قرع"),
    "🥜 مكسرات" to listOf("Almond" to "لوز", "Walnut" to "جوز", "Pistachio" to "فستق", "Cashew" to "كاجو", "Hazelnut" to "بندق", "Peanut" to "فول سوداني", "Date palm" to "نخيل التمر"),
    "🍽️ أطعمة" to listOf("Bread" to "خبز", "Rice" to "أرز", "Cheese" to "جبن", "Egg as food" to "بيض", "Honey" to "عسل", "Pizza" to "بيتزا", "Falafel" to "فلافل", "Koshari" to "كشري", "Milk" to "لبن", "Chocolate" to "شوكولاتة"),
    "🌳 أشجار" to listOf("Oak" to "بلوط", "Pine" to "صنوبر", "Olive" to "زيتون", "Palm tree" to "نخلة", "Sycamore" to "جميز", "Baobab" to "باوباب", "Cedrus libani" to "أرز لبنان", "Acacia" to "سنط", "Eucalyptus" to "كافور"),
    "✏️ أدوات مدرسية" to listOf("Pencil" to "قلم رصاص", "Eraser" to "ممحاة", "Ruler" to "مسطرة", "Backpack" to "حقيبة مدرسية", "Notebook" to "كراسة", "Scissors" to "مقص", "Blackboard" to "سبورة", "Globe" to "كرة أرضية", "Compass (drawing tool)" to "فرجار"),
    "🍳 أدوات مطبخ" to listOf("Frying pan" to "مقلاة", "Knife" to "سكين", "Spoon" to "ملعقة", "Fork" to "شوكة", "Kettle" to "غلاية", "Refrigerator" to "ثلاجة", "Blender" to "خلاط", "Oven" to "فرن", "Colander" to "مصفاة"),
    "🧹 أدوات نظافة" to listOf("Broom" to "مكنسة", "Vacuum cleaner" to "مكنسة كهربائية", "Mop" to "ممسحة", "Soap" to "صابون", "Sponge" to "إسفنجة", "Toothbrush" to "فرشاة أسنان", "Washing machine" to "غسالة"),
    "🏠 البيت والأثاث" to listOf("Sofa" to "كنبة", "Bed" to "سرير", "Chair" to "كرسي", "Table" to "طاولة", "Wardrobe" to "دولاب", "Door" to "باب", "Window" to "شباك", "Carpet" to "سجادة", "Chandelier" to "نجفة", "Kitchen" to "مطبخ"),
    "🎡 ملاهي وحديقة" to listOf("Ferris wheel" to "نورية", "Roller coaster" to "ملاهي الأفعوانية", "Carousel" to "دوّارة", "Swing (seat)" to "أرجوحة", "Slide (playground)" to "زحليقة", "Seesaw" to "أرجوحة التوازن", "Fountain" to "نافورة", "Bench (furniture)" to "مقعد حديقة"),
    "🌍 طبيعة" to listOf("Mountain" to "جبل", "Volcano" to "بركان", "River" to "نهر", "Desert" to "صحراء", "Waterfall" to "شلال", "Rainbow" to "قوس قزح", "Moon" to "قمر", "Sun" to "شمس", "Cloud" to "سحابة", "Island" to "جزيرة"),
)

data class Info(val title: String, val text: String, val image: String?, val url: String, val lang: String, val enTitle: String = "", val enText: String = "")

object Wiki {
    private fun get(u: String): String? = try {
        val c = URL(u).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", "SeeAndLearn/1.0 (educational app)")
        c.connectTimeout = 8000; c.readTimeout = 8000
        if (c.responseCode == 200) c.inputStream.bufferedReader().readText() else null
    } catch (e: Exception) { null }

    private fun enc(s: String) = URLEncoder.encode(s.replace(' ', '_'), "UTF-8")

    suspend fun thumb(en: String): String? = withContext(Dispatchers.IO) {
        get("https://en.wikipedia.org/api/rest_v1/page/summary/${enc(en)}")?.let { JSONObject(it).optJSONObject("thumbnail")?.optString("source") }
    }

    suspend fun arName(en: String): String = withContext(Dispatchers.IO) {
        try {
            get("https://en.wikipedia.org/w/api.php?action=query&titles=${enc(en)}&prop=langlinks&lllang=ar&format=json&redirects=1")?.let {
                val pages = JSONObject(it).getJSONObject("query").getJSONObject("pages")
                pages.getJSONObject(pages.keys().next()).optJSONArray("langlinks")?.getJSONObject(0)?.optString("*")
            } ?: en
        } catch (e: Exception) { en }
    }

    private fun arSearch(q: String): Info? {
        val arr = get("https://ar.wikipedia.org/w/api.php?action=opensearch&search=${URLEncoder.encode(q, "UTF-8")}&limit=1&format=json")?.let { org.json.JSONArray(it) } ?: return null
        val t = arr.optJSONArray(1)?.optString(0)?.takeIf { it.isNotBlank() } ?: return null
        val o = get("https://ar.wikipedia.org/api/rest_v1/page/summary/${enc(t)}")?.let(::JSONObject) ?: return null
        return Info(o.optString("title"), o.optString("extract"), o.optJSONObject("thumbnail")?.optString("source"),
            o.optJSONObject("content_urls")?.optJSONObject("mobile")?.optString("page") ?: "", "ar")
    }

    /** يجيب ملخص عربي من ويكيبيديا (أو إنجليزي لو مفيش) + صورة + رابط المصدر */
    suspend fun info(term: String): Info? = withContext(Dispatchers.IO) {
        if (term.startsWith("ar:")) return@withContext arSearch(term.removePrefix("ar:"))
        val en = get("https://en.wikipedia.org/api/rest_v1/page/summary/${enc(term)}")?.let(::JSONObject) ?: return@withContext null
        val arTitle = try {
            get("https://en.wikipedia.org/w/api.php?action=query&titles=${enc(term)}&prop=langlinks&lllang=ar&format=json&redirects=1")?.let {
                val pages = JSONObject(it).getJSONObject("query").getJSONObject("pages")
                pages.getJSONObject(pages.keys().next()).optJSONArray("langlinks")?.getJSONObject(0)?.optString("*")
            }
        } catch (e: Exception) { null }
        val ar = arTitle?.let { t -> get("https://ar.wikipedia.org/api/rest_v1/page/summary/${enc(t)}")?.let(::JSONObject) }
        val o = ar ?: en
        val img = o.optJSONObject("thumbnail")?.optString("source") ?: en.optJSONObject("thumbnail")?.optString("source")
        val url = o.optJSONObject("content_urls")?.optJSONObject("mobile")?.optString("page") ?: ""
        Info(o.optString("title"), o.optString("extract"), img, url, if (ar != null) "ar" else "en", en.optString("title"), en.optString("extract"))
    }
}
