package com.seeandlearn

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

fun firstSentences(text: String, n: Int): String =
    text.split(Regex("(?<=[.!؟?])\\s+")).filter { it.isNotBlank() }.take(n).joinToString(" ")

@Composable
fun WordImage(w: Word, modifier: Modifier) {
    val f = Store.photoFile(w)
    Box(modifier.background(Palette[abs(w.key.hashCode()) % Palette.size].copy(alpha = 0.2f)), Alignment.Center) {
        if (f != null) AsyncImage(f, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else if (w.wikiImg != null) WikiImage(w.wikiImg, Modifier.fillMaxSize(), ContentScale.Crop)
        else Text("🖼️", fontSize = 36.sp)
    }
}

@Composable
fun WordCard(w: Word, big: Boolean, onClick: () -> Unit) {
    Card(Modifier.clickable { onClick() }, shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(4.dp)) {
        Column {
            WordImage(w, Modifier.fillMaxWidth().height(if (big) 170.dp else 120.dp))
            Column(Modifier.padding(10.dp)) {
                Text(w.ar, fontSize = if (big) 24.sp else 18.sp, fontWeight = FontWeight.Bold)
                Text(w.en, fontSize = 13.sp, color = Color.Gray)
            }
        }
    }
}

/** ألبوم الطفل: كل اللي صوّره، وبطاقات التواصل، ومراجعة البومة */
@Composable
fun AlbumScreen() {
    var comm by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf<Word?>(null) }
    var review by remember { mutableStateOf(false) }
    if (review) { ReviewScreen { review = false }; return }
    Column(Modifier.fillMaxSize()) {
        Banner("📒 ألبومي", "${Store.album.size} كلمة اتعلّمتها", Purple, Pink)
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BigBtn("🦉 مراجعة (${Store.dueWords().size})", Orange, Modifier.weight(1f)) { if (Store.album.isNotEmpty()) review = true }
            BigBtn(if (comm) "📒 عرض عادي" else "🗣️ بطاقات تواصل", Teal, Modifier.weight(1f)) { comm = !comm }
        }
        if (Store.album.isEmpty()) {
            Text("🦉 لسه مفيش كلمات!\nصوّر حاجة أو اعمل مهمة وأنا هحفظها هنا وأفكّرك بيها.", fontSize = 18.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(24.dp))
        } else {
            LazyVerticalGrid(GridCells.Fixed(2), modifier = Modifier.weight(1f), contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(Store.album.toList()) { w -> WordCard(w, comm) { if (comm) Sfx.speak(w.ar) else sel = w } }
            }
        }
    }
    sel?.let { w ->
        AlertDialog(
            onDismissRequest = { sel = null },
            confirmButton = { TextButton({ sel = null }) { Text("تمام", fontSize = 18.sp) } },
            title = { Text(w.ar, fontWeight = FontWeight.Bold, fontSize = 26.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    WordImage(w, Modifier.fillMaxWidth().height(200.dp).clip(RoundedCornerShape(16.dp)))
                    Text("🇬🇧 ${w.en}", fontSize = 20.sp, color = Purple, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        BigBtn("🔊 عربي", Green, Modifier.weight(1f)) { Sfx.speak(w.ar) }
                        BigBtn("🔊 English", Blue, Modifier.weight(1f)) { Sfx.speakEn(w.en) }
                    }
                    Text("اتصوّرت ${w.seen} مرة  •  صح ${w.right}  •  غلط ${w.wrong}", fontSize = 14.sp, color = Color.Gray)
                }
            }
        )
    }
}

/** البومة بتسألك على الكلمات بنظام التكرار المتباعد */
@Composable
fun ReviewScreen(onExit: () -> Unit) {
    val queue = remember { Store.reviewQueue() }
    var i by remember { mutableStateOf(0) }
    var answered by remember { mutableStateOf<String?>(null) }
    var right by remember { mutableStateOf(0) }
    BackHandler { onExit() }
    if (queue.isEmpty() || i >= queue.size) {
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("🎉", fontSize = 80.sp)
            Text("خلّصنا المراجعة!", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Purple)
            Text("صح $right من ${queue.size}", fontSize = 20.sp)
            Spacer(Modifier.height(16.dp))
            BigBtn("رجوع للألبوم", Purple, Modifier.fillMaxWidth()) { onExit() }
        }
    } else {
        val w = queue[i]
        val opts = remember(i) {
            val others = Store.album.filter { it.key != w.key }.map { it.ar }
            val filler = Catalog.values.flatten().map { it.second }.filter { it != w.ar }
            ((others.shuffled() + filler.shuffled()).distinct().take(3) + w.ar).shuffled()
        }
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Banner("🦉 مراجعة البومة", "${i + 1} / ${queue.size}   •   ⭐ ${Store.stars.value}", Orange, Pink)
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("فاكر ده إيه يا ${Sfx.name}؟", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Purple)
                WordImage(w, Modifier.fillMaxWidth().height(240.dp).clip(RoundedCornerShape(24.dp)))
                opts.forEachIndexed { k, o ->
                    val base = Palette[k % Palette.size]
                    val c = when {
                        answered == null -> base
                        o == w.ar -> Color(0xFF2E9E5B)
                        o == answered -> Color(0xFFD63031)
                        else -> base.copy(alpha = 0.35f)
                    }
                    Button({
                        if (answered == null) {
                            answered = o
                            val ok = o == w.ar
                            Store.review(w.key, ok)
                            if (ok) { right++; Store.correct("review"); Sfx.correct() } else Sfx.wrong()
                        }
                    }, Modifier.fillMaxWidth().height(60.dp), shape = RoundedCornerShape(22.dp), colors = ButtonDefaults.buttonColors(containerColor = c)) {
                        Text(o, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                }
                if (answered != null) {
                    Text(if (answered == w.ar) "🎉 برافو! فاكرها" else "😅 دي ${w.ar} (${w.en})، هنراجعها تاني قريب",
                        fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                    BigBtn("التالي ⏭️", Purple, Modifier.fillMaxWidth()) { answered = null; i++ }
                }
            }
        }
    }
}

@Composable
fun MenuCard(title: String, desc: String, color: Color, onClick: () -> Unit) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(color).clickable { onClick() }.padding(22.dp)) {
        Column {
            Text(title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(desc, color = Color.White.copy(alpha = 0.95f), fontSize = 16.sp)
        }
    }
}

@Composable
fun MoreScreen(sub: Int, setSub: (Int) -> Unit, cat: String?, open: String?, setCat: (String?) -> Unit, setOpen: (String?) -> Unit,
               topic: String, setTopic: (String) -> Unit) {
    if (sub == 0) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Banner("⋯ المزيد", "استكشف وتعلّم أكتر", Green, Teal)
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                MenuCard("📚 تصفّح العالم", "حيوانات، فواكه، أشجار، أدوات... كلها بصورها", Green) { setSub(1) }
                MenuCard("👨‍👩‍👧 لوحة الأهل", "تقدّم الطفل وكلماته ونقاط ضعفه", Blue) { setSub(3) }
            }
        }
    } else {
        Column(Modifier.fillMaxSize()) {
            TextButton({ if (sub == 1 && open != null) setOpen(null) else if (sub == 1 && cat != null) setCat(null) else setSub(0) }) { Text("➡️ رجوع", fontSize = 18.sp) }
            Box(Modifier.weight(1f)) {
                when (sub) { 1 -> BrowseScreen(cat, open, setCat, setOpen, setTopic); else -> ParentScreen() }
            }
        }
    }
}

@Composable
fun RowScope.StatCard(icon: String, label: String, value: Int) {
    Card(Modifier.weight(1f), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(14.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, fontSize = 30.sp)
            Text("$value", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Purple)
            Text(label, fontSize = 14.sp, color = Color.Gray)
        }
    }
}

@Composable
fun InfoCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Purple)
            content()
        }
    }
}

/** لوحة الأهل والمعلمين: تقدّم الطفل ونقاط ضعفه (محمية بمسألة حساب) */
@Composable
fun ParentScreen() {
    val ctx = LocalContext.current
    var unlocked by remember { mutableStateOf(false) }
    val x = remember { (3..9).random() }
    val y = remember { (3..9).random() }
    var ans by remember { mutableStateOf("") }
    var bad by remember { mutableStateOf(false) }
    if (!unlocked) {
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("🔒", fontSize = 64.sp)
            Text("للأهل والمعلمين فقط", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("حلّي المسألة علشان تفتحي:", fontSize = 16.sp)
            Text("$x + $y = ؟", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Purple)
            OutlinedTextField(ans, { ans = it; bad = false }, singleLine = true, label = { Text("الإجابة") })
            if (bad) Text("إجابة غلط، جرّبي تاني", color = Red)
            Spacer(Modifier.height(10.dp))
            BigBtn("فتح", Purple, Modifier.fillMaxWidth()) { if (ans.trim().toIntOrNull() == x + y) unlocked = true else bad = true }
        }
        return
    }
    val words = Store.album.toList()
    val now = System.currentTimeMillis()
    val mastered = words.filter { it.box >= 3 }
    val weak = words.filter { it.wrong > it.right || (it.wrong > 0 && it.box <= 1) }
    val week = words.count { it.added > now - 7 * 86400000L }
    val due = Store.dueWords().size
    val frac = if (words.isEmpty()) 0f else mastered.size.toFloat() / words.size
    val tips = buildList {
        if (words.isEmpty()) add("ابدئي بتصوير حاجات من البيت أو مهمة اكتشاف، وهتظهر الكلمات هنا.")
        if (weak.isNotEmpty()) add("ركّزي على: ${weak.take(3).joinToString("، ") { it.ar }}. اسأليه عنها في حياته اليومية.")
        if (due > 0) add("فيه $due كلمة محتاجة مراجعة، شجّعيه يدوس 🦉 مراجعة في الألبوم.")
        if (words.isNotEmpty() && week == 0) add("ماتصوّرش حاجة جديدة الأسبوع ده، جرّبي معاه مهمة اكتشاف.")
        if (words.isNotEmpty() && weak.isEmpty() && due == 0) add("ممتاز! الطفل ماشي كويس، زوّدي له تحدي بمهام جديدة.")
    }
    fun report(): String {
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        return buildString {
            appendLine("تقرير تقدّم ${Sfx.name} — $d")
            appendLine("النجوم: ${Store.stars.value}  |  الكلمات: ${words.size}  |  المحفوظة: ${mastered.size}  |  المهام: ${Store.missions()}")
            appendLine("كلمات جديدة آخر 7 أيام: $week")
            if (weak.isNotEmpty()) appendLine("كلمات محتاجة تركيز: " + weak.joinToString("، ") { "${it.ar} (${it.en})" })
            if (mastered.isNotEmpty()) appendLine("كلمات محفوظة: " + mastered.joinToString("، ") { it.ar })
        }
    }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Banner("👨‍👩‍👧 لوحة الأهل", "متابعة تقدّم ${Sfx.name}", Blue, Purple)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { StatCard("⭐", "نجوم", Store.stars.value); StatCard("📒", "كلمات", words.size) }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { StatCard("🎯", "مهام", Store.missions()); StatCard("🗓️", "آخر ٧ أيام", week) }
            InfoCard("نسبة الحفظ") {
                Box(Modifier.fillMaxWidth().height(16.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFFE0E0E0))) {
                    Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(Green))
                }
                Text("${mastered.size} من ${words.size} كلمة محفوظة (${(frac * 100).toInt()}٪)", fontSize = 15.sp)
            }
            InfoCard("💡 نصايح") { if (tips.isEmpty()) Text("—") else tips.forEach { Text("• $it", fontSize = 15.sp) } }
            InfoCard("🔴 كلمات محتاجة تركيز") {
                if (weak.isEmpty()) Text("مفيش 🎉", fontSize = 15.sp) else weak.forEach { Text("${it.ar}  (${it.en})  —  صح ${it.right} / غلط ${it.wrong}", fontSize = 15.sp) }
            }
            InfoCard("✅ كلمات محفوظة") {
                if (mastered.isEmpty()) Text("لسه", fontSize = 15.sp) else Text(mastered.joinToString("، ") { it.ar }, fontSize = 15.sp)
            }
            InfoCard("📋 كل الكلمات") {
                words.forEach {
                    val st = if (it.box >= 3) "✅ محفوظة" else if (it.box >= 1) "🟡 بتتعلّم" else "🔴 جديدة"
                    Text("${it.ar} — ${it.en}   $st", fontSize = 15.sp)
                }
            }
            BigBtn("📤 مشاركة التقرير", Green, Modifier.fillMaxWidth()) {
                val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, report()) }
                ctx.startActivity(Intent.createChooser(i, "مشاركة التقرير"))
            }
        }
    }
}
