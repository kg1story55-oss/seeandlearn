package com.seeandlearn

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaPlayer
import android.media.ToneGenerator
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.util.Base64
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.io.File
import java.util.Locale

/** أصوات: مؤثرات + نطق عربي بصوت Gemini (مع تخزين على الجهاز وبديل صوت الجهاز) */
object Sfx {
    var name = ""
    val loading = mutableStateOf(false)
    private var tts: TextToSpeech? = null
    private var dir: File? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var track: AudioTrack? = null
    private val mem = object : LinkedHashMap<String, Pcm>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Pcm>?): Boolean = size > 24
    }
    private val praise = listOf("برافو", "عاش", "شاطر", "ممتاز")

    fun init(ctx: Context) {
        if (tts == null) tts = TextToSpeech(ctx.applicationContext) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("ar") }
        dir = File(ctx.cacheDir, "tts").also { it.mkdirs() }
    }

    // ---- تخزين الصوت على الجهاز ----
    private fun keyOf(t: String, eg: Boolean) = "${if (eg) "e" else "m"}${Integer.toHexString(t.hashCode())}x${t.length}"
    private fun readDisk(k: String): Pcm? {
        val f = dir?.listFiles()?.firstOrNull { it.name.startsWith(k + "_") } ?: return null
        return try { Pcm(f.readBytes(), f.name.substringAfterLast('_').removeSuffix(".pcm").toInt()) } catch (e: Exception) { null }
    }
    private fun writeDisk(k: String, p: Pcm) {
        val d = dir ?: return
        try {
            val files = d.listFiles()
            if (files != null && files.sumOf { it.length() } > 30_000_000L) files.sortedBy { it.lastModified() }.take(10).forEach { it.delete() }
            File(d, "${k}_${p.rate}.pcm").writeBytes(p.bytes)
        } catch (e: Exception) { }
    }

    /** يقص الذيل الهادي/الخشخشة في آخر الصوت ويعمل تلاشي ناعم */
    private fun clean(p: Pcm): Pcm {
        val n = p.bytes.size / 2
        val frame = p.rate / 50
        if (n < p.rate / 2 || frame <= 0) return p
        val frames = n / frame
        val rms = DoubleArray(frames) { f ->
            var sum = 0.0
            for (i in f * frame until (f + 1) * frame) {
                val s = ((p.bytes[2 * i].toInt() and 0xFF) or (p.bytes[2 * i + 1].toInt() shl 8)).toShort().toInt()
                sum += s.toDouble() * s
            }
            Math.sqrt(sum / frame)
        }
        val peak = rms.maxOrNull() ?: return p
        val thr = peak * 0.05
        var last = frames - 1
        while (last > 0 && rms[last] < thr) last--
        val keep = minOf(frames, last + 1 + 8) * frame      // + حوالي 160 مللي ثانية أمان
        val out = p.bytes.copyOf(keep * 2)
        val fade = minOf(keep, p.rate / 12)                  // تلاشي ~80 مللي ثانية
        for (i in 0 until fade) {
            val idx = (keep - fade + i) * 2
            val s = ((out[idx].toInt() and 0xFF) or (out[idx + 1].toInt() shl 8)).toShort().toInt()
            val v = (s * (1f - i.toFloat() / fade)).toInt()
            out[idx] = (v and 0xFF).toByte(); out[idx + 1] = ((v shr 8) and 0xFF).toByte()
        }
        return Pcm(out, p.rate)
    }

    private suspend fun fetch(t: String, eg: Boolean): Pcm? {
        val k = keyOf(t, eg)
        synchronized(mem) { mem[k] }?.let { return it }
        readDisk(k)?.let { synchronized(mem) { mem[k] = it }; return it }
        if (BuildConfig.GEMINI_KEY.isBlank()) return null
        val raw = Gemini.tts(t, BuildConfig.GEMINI_KEY, eg) ?: return null
        val got = clean(raw)
        synchronized(mem) { mem[k] = got }
        writeDisk(k, got)
        return got
    }

    private fun ensureEnd(s: String): String = if (s.isNotEmpty() && s.last() in ".!؟?…") s else "$s."

    /** يقسّم الكلام جُمَل: أول جزء قصير علشان يبدأ بسرعة */
    private fun chunks(t: String): List<String> {
        val sents = t.split(Regex("(?<=[.!؟?،,])\\s+")).filter { it.isNotBlank() }
        val out = mutableListOf<String>()
        var cur = ""
        for (s in sents) {
            val limit = if (out.isEmpty()) 90 else 170
            if (cur.isNotEmpty() && cur.length + s.length > limit) { out.add(cur); cur = s } else cur = if (cur.isEmpty()) s else "$cur $s"
        }
        if (cur.isNotEmpty()) out.add(cur)
        return out.map { ensureEnd(it) }
    }

    private fun stopAll() {
        job?.cancel()
        try { track?.stop(); track?.release() } catch (e: Exception) { }
        track = null; tts?.stop()
    }
    private fun play(p: Pcm) {
        try { track?.stop(); track?.release() } catch (e: Exception) { }
        val n = p.bytes.size and -2
        val at = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(p.rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(n).setTransferMode(AudioTrack.MODE_STATIC).build()
        at.write(p.bytes, 0, n)
        track = at
        at.play()
    }
    private fun fallback(text: String) { tts?.language = Locale("ar"); tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u") }

    /** ينطق بالعربي. egyptian: بس بيفرّق في التخزين، والنص نفسه هو اللي بيحدد اللهجة */
    fun speak(text: String, egyptian: Boolean = false) {
        val t = text.trim().take(450)
        if (t.isEmpty()) return
        stopAll()
        loading.value = true
        job = scope.launch {
            try {
                val parts = chunks(t)
                var pending: Deferred<Pcm?> = async { fetch(parts[0], egyptian) }
                for (i in parts.indices) {
                    val p = pending.await()
                    ensureActive()
                    if (p == null) { fallback(parts.drop(i).joinToString(" ")); return@launch }
                    val nxt: Deferred<Pcm?>? = if (i + 1 < parts.size) async { fetch(parts[i + 1], egyptian) } else null
                    loading.value = false
                    play(p)
                    delay(p.bytes.size / 2 * 1000L / p.rate + 40)
                    if (nxt != null) pending = nxt
                }
            } finally { loading.value = false }
        }
    }
    fun speakEn(t: String) { stopAll(); tts?.language = Locale.US; tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "e") }

    /** يجهّز جمل التشجيع مسبقًا علشان تشتغل فورًا */
    fun prefetch() {
        if (BuildConfig.GEMINI_KEY.isBlank() || name.isBlank()) return
        scope.launch {
            for (p in praise.map { "$it يا $name" } + "حاول تاني يا بطل") { fetch(ensureEnd(p), true); delay(2500) }
        }
    }

    private fun tones(vararg t: Pair<Int, Int>) = Thread {
        try { val g = ToneGenerator(AudioManager.STREAM_MUSIC, 85); t.forEach { g.startTone(it.first, it.second); Thread.sleep(it.second + 40L) }; g.release() } catch (e: Exception) { }
    }.start()
    fun correct(say: String? = null) {
        tones(ToneGenerator.TONE_DTMF_4 to 110, ToneGenerator.TONE_DTMF_8 to 110, ToneGenerator.TONE_DTMF_P to 250)
        Handler(Looper.getMainLooper()).postDelayed({ speak(say ?: (praise.random() + if (name.isNotBlank()) " يا $name" else ""), true) }, 650)
    }
    fun wrong() {
        tones(ToneGenerator.TONE_PROP_NACK to 350)
        Handler(Looper.getMainLooper()).postDelayed({ speak("حاول تاني يا بطل", true) }, 600)
    }
}

object Music {
    private var mp: MediaPlayer? = null
    private var enabled = false
    fun set(ctx: Context, on: Boolean) {
        enabled = on
        if (on) {
            if (mp == null) mp = MediaPlayer.create(ctx.applicationContext, R.raw.bgm)?.apply { isLooping = true; setVolume(0.2f, 0.2f) }
            mp?.start()
        } else mp?.pause()
    }
    fun pause() { mp?.pause() }
    fun resume() { if (enabled) mp?.start() }
}

fun loadBitmap(ctx: Context, u: Uri): Bitmap? = try {
    ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 2 }) }
} catch (e: Exception) { null }

/** تعرّف دقيق اختياري عبر Gemini (يحتاج مفتاح مجاني) */
data class GResult(val title: String?, val error: String?)
class Pcm(val bytes: ByteArray, val rate: Int)
data class MResult(val ok: Boolean?, val name: String?, val error: String?)

object Gemini {
    private const val PROMPT = "Identify the main object, animal, plant or food in this image as precisely as possible. Reply with ONLY its English Wikipedia article title (for example: Giraffe, Lion, Cucumber, Garlic, Frying pan). No other text."
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"
    private var cached: List<String>? = null

    private fun open(url: String, key: String, post: Boolean, read: Int = 15000): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = read
        c.setRequestProperty("x-goog-api-key", key)
        if (post) { c.requestMethod = "POST"; c.doOutput = true; c.setRequestProperty("Content-Type", "application/json") }
        return c
    }
    private fun err(c: HttpURLConnection): String {
        val body = try { c.errorStream?.bufferedReader()?.readText() ?: "" } catch (e: Exception) { "" }
        val msg = try { JSONObject(body).getJSONObject("error").getString("message") } catch (e: Exception) { body }
        return "HTTP ${c.responseCode}: ${msg.take(140)}"
    }
    private var all: List<String>? = null
    private var ttsList: List<String>? = null

    private fun allModels(key: String): List<String> {
        all?.let { return it }
        val c = open("$BASE/models?pageSize=200", key, false)
        if (c.responseCode != 200) throw Exception(err(c))
        val arr = JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("models")
        val names = (0 until arr.length()).map { arr.getJSONObject(it) }.filter { m ->
            val s = m.optJSONArray("supportedGenerationMethods"); s != null && (0 until s.length()).any { s.getString(it) == "generateContent" }
        }.map { it.getString("name").removePrefix("models/") }
        all = names; return names
    }

    private fun models(key: String): List<String> {
        cached?.let { return it }
        val names = allModels(key).filter { it.contains("flash") && listOf("image", "tts", "live", "audio", "preview", "exp").none { x -> it.contains(x) } }
        val order = names.filter { it.contains("lite") }.sortedDescending() +
            names.filter { Regex("^gemini-[0-9.]+-flash$").matches(it) }.sortedDescending() +
            names.filter { it == "gemini-flash-latest" }
        val list = order.distinct().take(4)
        if (list.isEmpty()) throw Exception("مفيش موديل مناسب في الحساب")
        cached = list; return list
    }

    private fun ttsModels(key: String): List<String> {
        ttsList?.let { return it }
        val names = allModels(key).filter { it.contains("tts") && !it.contains("live") }
        val order = names.filter { !it.contains("lite") && !it.contains("preview") }.sortedDescending() +
            names.filter { it.contains("lite") && !it.contains("preview") }.sortedDescending() +
            names.filter { it.contains("preview") }.sortedDescending()
        val list = order.distinct().take(3)
        ttsList = list; return list
    }

    /** نطق عصبي طبيعي. يرجّع صوت PCM أو null لو فشل */
    suspend fun tts(text: String, key: String, egyptian: Boolean): Pcm? = withContext(Dispatchers.IO) {
        try {
            val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text)))))
                .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO"))
                    .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", "Leda")))))
            for (m in ttsModels(key)) {
                try {
                    val c = open("$BASE/models/$m:generateContent", key, true, 40000)
                    c.outputStream.use { it.write(body.toString().toByteArray()) }
                    if (c.responseCode != 200) continue
                    val parts = JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts")
                    for (i in 0 until parts.length()) {
                        val p = parts.getJSONObject(i)
                        val d = p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data") ?: continue
                        val mime = d.optString("mimeType", d.optString("mime_type", ""))
                        val rate = Regex("rate=(\\d+)").find(mime)?.groupValues?.get(1)?.toIntOrNull() ?: 24000
                        return@withContext Pcm(Base64.decode(d.getString("data"), Base64.DEFAULT), rate)
                    }
                } catch (e: Exception) { continue }
            }
            null
        } catch (e: Exception) { null }
    }

    private fun call(model: String, key: String, data: String, thinking: Boolean, prompt: String, json: Boolean): Pair<Int, String> = try {
        val gen = JSONObject().put("temperature", 0).put("maxOutputTokens", 400)
        if (json) gen.put("responseMimeType", "application/json")
        if (thinking) gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        val body = JSONObject().put("generationConfig", gen).put("contents", JSONArray().put(JSONObject().put("parts", JSONArray()
            .put(JSONObject().put("text", prompt))
            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", data))))))
        val c = open("$BASE/models/$model:generateContent", key, true)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        if (code == 200) code to c.inputStream.bufferedReader().readText() else code to err(c)
    } catch (e: Exception) { -1 to "انتهت المهلة" }

    /** يسأل Gemini عن الصورة. يرجّع (النص، الخطأ) */
    private suspend fun ask(b: Bitmap, key: String, prompt: String, json: Boolean): Pair<String?, String?> = withContext(Dispatchers.IO) {
        try {
            val list = models(key)
            val scale = 512f / maxOf(b.width, b.height).coerceAtLeast(1)
            val sb = if (scale < 1f) Bitmap.createScaledBitmap(b, (b.width * scale).toInt(), (b.height * scale).toInt(), true) else b
            val bos = ByteArrayOutputStream(); sb.compress(Bitmap.CompressFormat.JPEG, 80, bos)
            val data = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
            var lastErr = "?"
            for (model in list) {
                for (thinking in listOf(true, false)) {
                    val (code, text) = call(model, key, data, thinking, prompt, json)
                    if (code == 200) {
                        val parts = JSONObject(text).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                        for (i in 0 until parts.length()) {
                            val t = parts.getJSONObject(i).optString("text", "").trim()
                            if (t.isNotBlank()) return@withContext Pair(t, null)
                        }
                        lastErr = "رد فاضي من $model"; break
                    }
                    lastErr = "$model → $text"
                    if (code == 400 && thinking) continue
                    break
                }
            }
            Pair(null, lastErr)
        } catch (e: Exception) { Pair(null, e.message?.take(160) ?: "خطأ في الاتصال") }
    }

    suspend fun identify(b: Bitmap, key: String): GResult {
        val (t, e) = ask(b, key, PROMPT, false)
        val clean = t?.trim('.', '"', '\n', ' ')?.ifBlank { null }
        return if (clean != null) GResult(clean, null) else GResult(null, e ?: "رد فاضي")
    }

    /** مهمة اكتشاف: هل الصورة فيها اللي اتطلب؟ وإيه هو بالظبط؟ */
    suspend fun checkMission(b: Bitmap, key: String, desc: String): MResult {
        val prompt = "A young child was asked to find and photograph: \"$desc\". Look at the photo and decide whether it clearly shows such a thing. " +
            "Reply ONLY as JSON: {\"ok\": true or false, \"name\": \"English Wikipedia article title of the main object in the photo\"}"
        val (t, e) = ask(b, key, prompt, true)
        if (t == null) return MResult(null, null, e)
        return try {
            val o = JSONObject(t.removePrefix("```json").removeSuffix("```").trim())
            MResult(o.optBoolean("ok"), o.optString("name").ifBlank { null }, null)
        } catch (ex: Exception) { MResult(null, null, "رد غير مفهوم") }
    }
}

@Composable
fun GamesHub() {
    var game by remember { mutableStateOf(0) }
    BackHandler(enabled = game != 0) { game = 0 }
    if (game == 0) {
        val games = listOf(
            Triple("🎮 إيه ده؟", "شوف الصورة واختار الاسم", Pink), Triple("🃏 ذاكرة الصور", "اربط كل صورة باسمها", Orange),
            Triple("👂 اسمع واختار", "اسمع الاسم واختار الصورة", Green), Triple("🔤 رتّب الحروف", "رتّب الحروف وكوّن الكلمة", Purple))
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Banner("🎮 الألعاب", "العب وتعلّم!", Pink, Purple)
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                games.forEachIndexed { i, (t, d, c) ->
                    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(c).clickable { game = i + 1 }.padding(22.dp)) {
                        Column { Text(t, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold); Text(d, color = Color.White.copy(alpha = 0.95f), fontSize = 16.sp) }
                    }
                }
            }
        }
    } else Column(Modifier.fillMaxSize()) {
        TextButton({ game = 0 }) { Text("➡️ كل الألعاب", fontSize = 16.sp) }
        Box(Modifier.weight(1f)) { when (game) { 1 -> QuizScreen(); 2 -> MemoryGame(); 3 -> ListenGame(); else -> SpellGame() } }
    }
}

private data class MCard(val key: String, val ar: String, val img: String?, val isImage: Boolean)

@Composable
fun MemoryGame() {
    val scope = rememberCoroutineScope()
    var round by remember { mutableStateOf(0) }
    var cards by remember { mutableStateOf<List<MCard>>(emptyList()) }
    val flipped = remember { mutableStateListOf<Int>() }
    val matched = remember { mutableStateListOf<String>() }
    var moves by remember { mutableStateOf(0) }
    LaunchedEffect(round) {
        cards = emptyList(); flipped.clear(); matched.clear(); moves = 0
        val picks = coroutineScope { Catalog.values.flatten().shuffled().take(10).map { async { it to Wiki.thumb(it.first) } }.awaitAll() }
            .filter { it.second != null }.take(6)
        cards = picks.flatMap { (p, im) -> listOf(MCard(p.first, p.second, im, true), MCard(p.first, p.second, im, false)) }.shuffled()
    }
    fun tap(i: Int) {
        if (flipped.size >= 2 || i in flipped || cards[i].key in matched) return
        flipped.add(i)
        if (flipped.size == 2) {
            moves++
            val a = cards[flipped[0]]; val b = cards[flipped[1]]
            scope.launch {
                if (a.key == b.key) { delay(300); matched.add(a.key); flipped.clear(); Sfx.correct() } else { delay(900); flipped.clear() }
            }
        }
    }
    Column(Modifier.fillMaxSize()) {
        Banner("🃏 ذاكرة الصور", "المحاولات: $moves", Orange, Pink)
        if (cards.isEmpty()) Box(Modifier.fillMaxWidth().padding(40.dp), Alignment.Center) { Text("🤔 بجهّز الكروت...", fontSize = 20.sp) }
        if (cards.isNotEmpty() && matched.size == cards.size / 2) {
            Text("🏆 كسبت في $moves محاولة!", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Green, modifier = Modifier.fillMaxWidth().padding(12.dp), textAlign = TextAlign.Center)
            BigBtn("🔄 لعبة جديدة", Purple, Modifier.fillMaxWidth().padding(horizontal = 16.dp)) { round++ }
        }
        LazyVerticalGrid(GridCells.Fixed(3), contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(cards.size) { i ->
                val c = cards[i]; val shown = i in flipped || c.key in matched
                Box(Modifier.aspectRatio(0.85f).clip(RoundedCornerShape(18.dp))
                    .background(if (shown) Color.White else Palette[i % Palette.size]).clickable { tap(i) }, contentAlignment = Alignment.Center) {
                    when {
                        !shown -> Text("❓", fontSize = 38.sp)
                        c.isImage -> WikiImage(c.img, Modifier.fillMaxSize(), ContentScale.Crop)
                        else -> Text(c.ar, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = Purple)
                    }
                }
            }
        }
    }
}

@Composable
fun ListenGame() {
    var round by remember { mutableStateOf(0) }
    var score by remember { mutableStateOf(0) }
    var opts by remember { mutableStateOf<List<Triple<String, String, String?>>>(emptyList()) }
    var target by remember { mutableStateOf(0) }
    var answered by remember { mutableStateOf<Int?>(null) }
    LaunchedEffect(round) {
        answered = null; opts = emptyList()
        val g = Catalog.values.toList().random().shuffled().take(4)
        opts = coroutineScope { g.map { async { Triple(it.first, it.second, Wiki.thumb(it.first)) } }.awaitAll() }
        target = (0..3).random(); delay(300); Sfx.speak("فين ${opts[target].second}؟")
    }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Banner("👂 اسمع واختار", "⭐ النقاط: $score", Green, Teal)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (opts.isEmpty()) Text("🤔 بجهّز...", fontSize = 20.sp)
            else {
                BigBtn("🔊 اسمع تاني", Blue, Modifier.fillMaxWidth()) { Sfx.speak("فين ${opts[target].second}؟") }
                for (row in 0..1) Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    for (col in 0..1) {
                        val i = row * 2 + col
                        val border = when { answered == null -> Color.Transparent; i == target -> Color(0xFF2E9E5B); i == answered -> Color(0xFFD63031); else -> Color.Transparent }
                        Card(Modifier.weight(1f).height(170.dp).clickable {
                            if (answered == null) { answered = i; if (i == target) { score++; Sfx.correct() } else Sfx.wrong() }
                        }, shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = border.takeIf { it != Color.Transparent } ?: Color.White)) {
                            Box(Modifier.fillMaxSize().padding(5.dp), Alignment.Center) {
                                if (opts[i].third != null) WikiImage(opts[i].third, Modifier.fillMaxSize().clip(RoundedCornerShape(18.dp)), ContentScale.Crop)
                                else Text(opts[i].second, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                if (answered != null) BigBtn("السؤال اللي بعده ⏭️", Purple, Modifier.fillMaxWidth()) { round++ }
            }
        }
    }
}

@Composable
fun SpellGame() {
    var round by remember { mutableStateOf(0) }
    var score by remember { mutableStateOf(0) }
    var item by remember { mutableStateOf<Pair<String, String>?>(null) }
    var img by remember { mutableStateOf<String?>(null) }
    var letters by remember { mutableStateOf<List<Char>>(emptyList()) }
    val picked = remember { mutableStateListOf<Int>() }
    var done by remember { mutableStateOf(false) }
    LaunchedEffect(round) {
        picked.clear(); done = false; img = null
        val p = Catalog.values.flatten().filter { !it.second.contains(' ') && it.second.length in 3..7 }.random()
        item = p; letters = p.second.toList().shuffled(); img = Wiki.thumb(p.first)
    }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Banner("🔤 رتّب الحروف", "⭐ النقاط: $score", Purple, Blue)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Card(Modifier.fillMaxWidth().height(220.dp), shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Box(Modifier.fillMaxSize().padding(6.dp), Alignment.Center) {
                    if (img != null) WikiImage(img, Modifier.fillMaxSize().clip(RoundedCornerShape(22.dp))) else Text("🤔", fontSize = 70.sp)
                }
            }
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Yellow.copy(alpha = 0.35f)).padding(16.dp), Alignment.Center) {
                Text(if (picked.isEmpty()) "؟ ؟ ؟" else picked.joinToString("") { letters[it].toString() }, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            }
            if (done) {
                Text("🎉 ${item?.second}", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Green, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                BigBtn("التالي ⏭️", Purple, Modifier.fillMaxWidth()) { round++ }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    letters.forEachIndexed { i, ch ->
                        Button({
                            picked.add(i)
                            if (picked.size == letters.size) {
                                if (picked.joinToString("") { letters[it].toString() } == item?.second) { score++; done = true; Sfx.correct(); item?.let { Sfx.speak(it.second) } }
                                else { Sfx.wrong(); picked.clear() }
                            }
                        }, Modifier.weight(1f).height(56.dp), enabled = i !in picked, contentPadding = PaddingValues(0.dp), shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Palette[i % Palette.size])) { Text(ch.toString(), fontSize = 24.sp, fontWeight = FontWeight.Bold) }
                    }
                }
                TextButton({ picked.clear() }, Modifier.fillMaxWidth()) { Text("🧹 امسح وابدأ تاني") }
            }
        }
    }
}
