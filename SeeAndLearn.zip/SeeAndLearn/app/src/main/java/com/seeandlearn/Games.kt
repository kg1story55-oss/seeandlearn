package com.seeandlearn

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.util.Base64
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** أصوات: مؤثرات + نطق عربي */
object Sfx {
    private var tts: TextToSpeech? = null
    private val praise = listOf("برافو", "أحسنت", "ممتاز", "شاطر", "رائع")
    fun init(ctx: Context) { if (tts == null) tts = TextToSpeech(ctx) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("ar") } }
    fun speak(t: String) { tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u") }
    private fun tones(vararg t: Pair<Int, Int>) = Thread {
        try { val g = ToneGenerator(AudioManager.STREAM_MUSIC, 85); t.forEach { g.startTone(it.first, it.second); Thread.sleep(it.second + 40L) }; g.release() } catch (e: Exception) { }
    }.start()
    fun correct() {
        tones(ToneGenerator.TONE_DTMF_4 to 110, ToneGenerator.TONE_DTMF_8 to 110, ToneGenerator.TONE_DTMF_P to 250)
        Handler(Looper.getMainLooper()).postDelayed({ speak(praise.random()) }, 650)
    }
    fun wrong() {
        tones(ToneGenerator.TONE_PROP_NACK to 350)
        Handler(Looper.getMainLooper()).postDelayed({ speak("حاول مرة تانية") }, 600)
    }
}

fun loadBitmap(ctx: Context, u: Uri): Bitmap? = try {
    ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 2 }) }
} catch (e: Exception) { null }

/** تعرّف دقيق اختياري عبر Gemini (يحتاج مفتاح مجاني) */
object Gemini {
    private const val PROMPT = "Identify the main object, animal, plant or food in this image as precisely as possible. Reply with ONLY its English Wikipedia article title (for example: Giraffe, Lion, Cucumber, Frying pan). No other text."
    private val models = listOf("gemini-flash-latest", "gemini-2.5-flash", "gemini-2.0-flash")
    suspend fun identify(b: Bitmap, key: String): String? = withContext(Dispatchers.IO) {
        try {
            val scale = 1024f / maxOf(b.width, b.height).coerceAtLeast(1)
            val sb = if (scale < 1f) Bitmap.createScaledBitmap(b, (b.width * scale).toInt(), (b.height * scale).toInt(), true) else b
            val bos = ByteArrayOutputStream(); sb.compress(Bitmap.CompressFormat.JPEG, 85, bos)
            val data = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
            val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray()
                .put(JSONObject().put("text", PROMPT))
                .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", data))))))
            for (m in models) {
                val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent?key=$key").openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 30000
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
                if (c.responseCode == 200) {
                    return@withContext JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text").trim().trim('.', '"', '\n', ' ')
                }
                if (c.responseCode == 400 || c.responseCode == 403) return@withContext null
            }
            null
        } catch (e: Exception) { null }
    }
}

@Composable
fun GamesHub() {
    var game by remember { mutableStateOf(0) }
    BackHandler(enabled = game != 0) { game = 0 }
    if (game == 0) {
        val games = listOf(
            Triple("🎮 إيه ده؟", "شوف الصورة واختار الاسم", Pink), Triple("🃏 ذاكرة الصور", "اربط كل صورة باسمها", Orange),
            Triple("👂 اسمع واختار", "اسمع الاسم واختار الصورة", Green), Triple("🔤 رتّب الحروف", "رتّب الحروف وكوّن الكلمة", Purple))
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Banner("🎮 الألعاب", "العب وتعلّم!", Pink, Purple)
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                games.forEachIndexed { i, (t, d, c) ->
                    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(c).clickable { game = i + 1 }.padding(22.dp)) {
                        Column { Text(t, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold); Text(d, color = Color.White.copy(alpha = 0.95f), fontSize = 16.sp) }
                    }
                }
            }
        }
    } else Column(Modifier.fillMaxSize()) {
        TextButton({ game = 0 }) { Text("➡️ كل الألعاب", fontSize = 16.sp) }
        Box(Modifier.weight(1f)) { when (game) { 1 -> QuizScreen(); 2 -> MemoryGame(); 3 -> ListenGame(); else -> SpellGame() } }
    }
}

private data class MCard(val key: String, val ar: String, val img: String?, val isImage: Boolean)

@Composable
fun MemoryGame() {
    val scope = rememberCoroutineScope()
    var round by remember { mutableStateOf(0) }
    var cards by remember { mutableStateOf<List<MCard>>(emptyList()) }
    val flipped = remember { mutableStateListOf<Int>() }
    val matched = remember { mutableStateListOf<String>() }
    var moves by remember { mutableStateOf(0) }
    LaunchedEffect(round) {
        cards = emptyList(); flipped.clear(); matched.clear(); moves = 0
        val picks = coroutineScope { Catalog.values.flatten().shuffled().take(10).map { async { it to Wiki.thumb(it.first) } }.awaitAll() }
            .filter { it.second != null }.take(6)
        cards = picks.flatMap { (p, im) -> listOf(MCard(p.first, p.second, im, true), MCard(p.first, p.second, im, false)) }.shuffled()
    }
    fun tap(i: Int) {
        if (flipped.size >= 2 || i in flipped || cards[i].key in matched) return
        flipped.add(i)
        if (flipped.size == 2) {
            moves++
            val a = cards[flipped[0]]; val b = cards[flipped[1]]
            scope.launch {
                if (a.key == b.key) { delay(300); matched.add(a.key); flipped.clear(); Sfx.correct() } else { delay(900); flipped.clear() }
            }
        }
    }
    Column(Modifier.fillMaxSize()) {
        Banner("🃏 ذاكرة الصور", "المحاولات: $moves", Orange, Pink)
        if (cards.isEmpty()) Box(Modifier.fillMaxWidth().padding(40.dp), Alignment.Center) { Text("🤔 بجهّز الكروت...", fontSize = 20.sp) }
        if (cards.isNotEmpty() && matched.size == cards.size / 2) {
            Text("🏆 كسبت في $moves محاولة!", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Green, modifier = Modifier.fillMaxWidth().padding(12.dp), textAlign = TextAlign.Center)
            BigBtn("🔄 لعبة جديدة", Purple, Modifier.fillMaxWidth().padding(horizontal = 16.dp)) { round++ }
        }
        LazyVerticalGrid(GridCells.Fixed(3), contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(cards.size) { i ->
                val c = cards[i]; val shown = i in flipped || c.key in matched
                Box(Modifier.aspectRatio(0.85f).clip(RoundedCornerShape(18.dp))
                    .background(if (shown) Color.White else Palette[i % Palette.size]).clickable { tap(i) }, contentAlignment = Alignment.Center) {
                    when {
                        !shown -> Text("❓", fontSize = 38.sp)
                        c.isImage -> WikiImage(c.img, Modifier.fillMaxSize(), ContentScale.Crop)
                        else -> Text(c.ar, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = Purple)
                    }
                }
            }
        }
    }
}

@Composable
fun ListenGame() {
    var round by remember { mutableStateOf(0) }
    var score by remember { mutableStateOf(0) }
    var opts by remember { mutableStateOf<List<Triple<String, String, String?>>>(emptyList()) }
    var target by remember { mutableStateOf(0) }
    var answered by remember { mutableStateOf<Int?>(null) }
    LaunchedEffect(round) {
        answered = null; opts = emptyList()
        val g = Catalog.values.toList().random().shuffled().take(4)
        opts = coroutineScope { g.map { async { Triple(it.first, it.second, Wiki.thumb(it.first)) } }.awaitAll() }
        target = (0..3).random(); delay(300); Sfx.speak("فين ${opts[target].second}؟")
    }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Banner("👂 اسمع واختار", "⭐ النقاط: $score", Green, Teal)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (opts.isEmpty()) Text("🤔 بجهّز...", fontSize = 20.sp)
            else {
                BigBtn("🔊 اسمع تاني", Blue, Modifier.fillMaxWidth()) { Sfx.speak("فين ${opts[target].second}؟") }
                for (row in 0..1) Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    for (col in 0..1) {
                        val i = row * 2 + col
                        val border = when { answered == null -> Color.Transparent; i == target -> Color(0xFF2E9E5B); i == answered -> Color(0xFFD63031); else -> Color.Transparent }
                        Card(Modifier.weight(1f).height(170.dp).clickable {
                            if (answered == null) { answered = i; if (i == target) { score++; Sfx.correct() } else Sfx.wrong() }
                        }, shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = border.takeIf { it != Color.Transparent } ?: Color.White)) {
                            Box(Modifier.fillMaxSize().padding(5.dp), Alignment.Center) {
                                if (opts[i].third != null) WikiImage(opts[i].third, Modifier.fillMaxSize().clip(RoundedCornerShape(18.dp)), ContentScale.Crop)
                                else Text(opts[i].second, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                if (answered != null) BigBtn("السؤال اللي بعده ⏭️", Purple, Modifier.fillMaxWidth()) { round++ }
            }
        }
    }
}

@Composable
fun SpellGame() {
    var round by remember { mutableStateOf(0) }
    var score by remember { mutableStateOf(0) }
    var item by remember { mutableStateOf<Pair<String, String>?>(null) }
    var img by remember { mutableStateOf<String?>(null) }
    var letters by remember { mutableStateOf<List<Char>>(emptyList()) }
    val picked = remember { mutableStateListOf<Int>() }
    var done by remember { mutableStateOf(false) }
    LaunchedEffect(round) {
        picked.clear(); done = false; img = null
        val p = Catalog.values.flatten().filter { !it.second.contains(' ') && it.second.length in 3..7 }.random()
        item = p; letters = p.second.toList().shuffled(); img = Wiki.thumb(p.first)
    }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Banner("🔤 رتّب الحروف", "⭐ النقاط: $score", Purple, Blue)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Card(Modifier.fillMaxWidth().height(220.dp), shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Box(Modifier.fillMaxSize().padding(6.dp), Alignment.Center) {
                    if (img != null) WikiImage(img, Modifier.fillMaxSize().clip(RoundedCornerShape(22.dp))) else Text("🤔", fontSize = 70.sp)
                }
            }
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Yellow.copy(alpha = 0.35f)).padding(16.dp), Alignment.Center) {
                Text(if (picked.isEmpty()) "؟ ؟ ؟" else picked.joinToString("") { letters[it].toString() }, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            }
            if (done) {
                Text("🎉 ${item?.second}", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Green, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                BigBtn("التالي ⏭️", Purple, Modifier.fillMaxWidth()) { round++ }
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    letters.forEachIndexed { i, ch ->
                        Button({
                            picked.add(i)
                            if (picked.size == letters.size) {
                                if (picked.joinToString("") { letters[it].toString() } == item?.second) { score++; done = true; Sfx.correct(); item?.let { Sfx.speak(it.second) } }
                                else { Sfx.wrong(); picked.clear() }
                            }
                        }, Modifier.weight(1f).height(56.dp), enabled = i !in picked, contentPadding = PaddingValues(0.dp), shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Palette[i % Palette.size])) { Text(ch.toString(), fontSize = 24.sp, fontWeight = FontWeight.Bold) }
                    }
                }
                TextButton({ picked.clear() }, Modifier.fillMaxWidth()) { Text("🧹 امسح وابدأ تاني") }
            }
        }
    }
}
