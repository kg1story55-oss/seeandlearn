package com.seeandlearn

import android.content.Context
import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class Mission(val ar: String, val en: String)

val Missions = listOf(
    Mission("حاجة بتتاكل ولونها أحمر", "something edible that is red"),
    Mission("حاجة بنكتب بيها", "something used for writing or drawing"),
    Mission("حاجة موجودة في المطبخ", "something found in a kitchen"),
    Mission("حاجة شكلها دايرة", "an object that is round or circular"),
    Mission("حيوان أو لعبة على شكل حيوان", "an animal or a toy animal"),
    Mission("حاجة بنشرب فيها", "something you drink from, like a cup or bottle"),
    Mission("حاجة بنقعد عليها", "something you sit on"),
    Mission("حاجة لونها أخضر", "something green"),
    Mission("نبات أو شجرة", "a plant or a tree"),
    Mission("حاجة بنستخدمها في النضافة", "a cleaning item"),
    Mission("حاجة موجودة في أوضة النوم", "something found in a bedroom"),
    Mission("حاجة بتنوّر", "something that gives light"),
    Mission("فاكهة", "a fruit"),
    Mission("خضار", "a vegetable"),
    Mission("حاجة مصنوعة من الورق", "something made of paper"),
    Mission("حاجة بنفتحها ونقفلها", "something that opens and closes, like a door, window or box"),
    Mission("لعبة", "a toy"),
    Mission("حاجة لونها أصفر", "something yellow"),
    Mission("حاجة بنحطها في شنطة المدرسة", "a school supply that goes in a school bag")
)

@Composable
fun MissionsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var idx by remember { mutableStateOf(Missions.indices.random()) }
    var busy by remember { mutableStateOf(false) }
    var success by remember { mutableStateOf<Boolean?>(null) }
    var found by remember { mutableStateOf<String?>(null) }
    var foundAr by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    var thumb by remember { mutableStateOf<Bitmap?>(null) }
    val m = Missions[idx]

    fun next() {
        idx = (Missions.indices - idx).random()
        success = null; found = null; msg = null; thumb = null
        Sfx.speak("هاتلي ${Missions[idx].ar}", true)
    }

    fun verify(b: Bitmap) {
        busy = true; success = null; found = null; msg = null; thumb = b
        scope.launch {
            val key = BuildConfig.GEMINI_KEY
            if (key.isBlank()) {
                msg = "⚠️ مفتاح الذكاء الاصطناعي مش موجود في النسخة دي."
            } else {
                val r = Gemini.checkMission(b, key, m.en)
                val nm = r.name
                if (r.ok == null) {
                    msg = "😕 معرفتش أوصل للذكاء الاصطناعي دلوقتي، حاولي تاني.\n(السبب: ${r.error})"
                } else {
                    foundAr = if (nm != null) Wiki.arName(nm) else ""
                    found = nm
                    if (r.ok == true && nm != null) {
                        success = true
                        Wiki.info(nm)?.let { Store.saveWord(it, b) }
                        Store.addStars(3); Store.missionDone()
                        Sfx.correct()
                        delay(2300); Sfx.speak("دي $foundAr", true)
                    } else {
                        success = false
                        Sfx.wrong()
                    }
                }
            }
            busy = false
        }
    }

    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { it?.let { b -> verify(b) } }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let { u -> loadBitmap(ctx, u)?.let { b -> verify(b) } } }

    Column(Modifier.verticalScroll(rememberScrollState())) {
        Banner("🎯 مهام الاكتشاف", "⭐ ${Store.stars.value} نجمة   •   خلّصت ${Store.missions()} مهمة", Teal, Blue)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(20.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🦉", fontSize = 64.sp)
                    Text("مهمتك يا بطل:", fontSize = 16.sp, color = Color.Gray)
                    Text("هاتلي ${m.ar}", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Purple, textAlign = TextAlign.Center)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        BigBtn("🔊 اسمع", Blue, Modifier.weight(1f)) { Sfx.speak("هاتلي ${m.ar}", true) }
                        BigBtn("🔄 مهمة تانية", Orange, Modifier.weight(1f)) { next() }
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BigBtn("📷 صوّر", Teal, Modifier.weight(1f)) { camera.launch(null) }
                BigBtn("🖼️ من الجهاز", Blue, Modifier.weight(1f)) { gallery.launch("image/*") }
            }
            thumb?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxWidth().heightIn(max = 260.dp).clip(RoundedCornerShape(24.dp))) }
            if (busy) Text("🔍 بتأكد من الصورة...", fontSize = 20.sp, color = Purple, fontWeight = FontWeight.Bold)
            msg?.let { Text(it, fontSize = 15.sp, color = Color(0xFF555555)) }
            if (success == true) {
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Green.copy(alpha = 0.3f))) {
                    Column(Modifier.padding(16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🎉 برافو! لقيتها", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("+٣ ⭐⭐⭐", fontSize = 22.sp)
                        Text(foundAr, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Purple)
                    }
                }
                found?.let { InfoPanel(it, { }) }
                BigBtn("➡️ المهمة اللي بعدها", Purple, Modifier.fillMaxWidth()) { next() }
            } else if (success == false) {
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Red.copy(alpha = 0.2f))) {
                    Column(Modifier.padding(16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🤔 مش دي المطلوبة", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        if (foundAr.isNotBlank()) Text("دي شكلها: $foundAr", fontSize = 18.sp)
                        Text("دوّر تاني على: ${m.ar}", fontSize = 18.sp, color = Purple, textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }
}
