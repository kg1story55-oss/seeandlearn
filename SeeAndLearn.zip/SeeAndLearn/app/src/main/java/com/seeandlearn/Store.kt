package com.seeandlearn

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** كلمة في ألبوم الطفل (box = مستوى الحفظ 0..4 للتكرار المتباعد) */
data class Word(
    val key: String, val ar: String, val en: String, val photo: String, val wikiImg: String?,
    val added: Long, val box: Int, val due: Long, val right: Int, val wrong: Int, val seen: Int
)

object Store {
    private lateinit var prefs: SharedPreferences
    private lateinit var dir: File
    val stars = mutableStateOf(0)
    val age = mutableStateOf(1)              // 0: 3-5 ، 1: 6-8 ، 2: 9-12
    val tick = mutableStateOf(0)
    val tashkeel = mutableStateOf(true)
    val voiceMode = mutableStateOf(1)        // 0: Gemini للكل ، 1: موفّر ، 2: صوت الجهاز
    val album = mutableStateListOf<Word>()
    private val day = 86400000L
    private val intervals = longArrayOf(0, day, 3 * day, 7 * day, 30 * day)

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("prefs", 0)
        dir = File(ctx.filesDir, "album").also { it.mkdirs() }
        stars.value = prefs.getInt("stars", 0)
        age.value = prefs.getInt("age", 1)
        voiceMode.value = prefs.getInt("voice", 1)
        tashkeel.value = prefs.getBoolean("tashkeel", true)
        album.clear()
        val arr = try { JSONArray(prefs.getString("album", "[]")) } catch (e: Exception) { JSONArray() }
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            album.add(Word(o.getString("key"), o.optString("ar"), o.optString("en"), o.optString("photo"), o.optString("wiki").ifBlank { null },
                o.optLong("added"), o.optInt("box"), o.optLong("due"), o.optInt("right"), o.optInt("wrong"), o.optInt("seen")))
        }
    }

    private fun saveAlbum() {
        val arr = JSONArray()
        album.forEach {
            arr.put(JSONObject().put("key", it.key).put("ar", it.ar).put("en", it.en).put("photo", it.photo).put("wiki", it.wikiImg ?: "")
                .put("added", it.added).put("box", it.box).put("due", it.due).put("right", it.right).put("wrong", it.wrong).put("seen", it.seen))
        }
        prefs.edit().putString("album", arr.toString()).apply()
    }

    fun addStars(n: Int) { stars.value += n; prefs.edit().putInt("stars", stars.value).apply() }
    fun setTashkeel(b: Boolean) { tashkeel.value = b; prefs.edit().putBoolean("tashkeel", b).apply() }
    fun setVoice(m: Int) { voiceMode.value = m; prefs.edit().putInt("voice", m).apply() }
    fun setAge(a: Int) { age.value = a; prefs.edit().putInt("age", a).apply() }

    /** يحفظ الكلمة في الألبوم. يرجّع true لو كلمة جديدة */
    fun saveWord(info: Info, bmp: Bitmap?): Boolean {
        val key = info.enTitle.ifBlank { info.title }
        val idx = album.indexOfFirst { it.key == key }
        if (idx >= 0) { album[idx] = album[idx].copy(seen = album[idx].seen + 1); saveAlbum(); return false }
        var photo = ""
        if (bmp != null) {
            try {
                val name = "w${System.currentTimeMillis()}.jpg"
                val s = 320f / maxOf(bmp.width, bmp.height).coerceAtLeast(1)
                val sb = if (s < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true) else bmp
                File(dir, name).outputStream().use { sb.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                photo = name
            } catch (e: Exception) { }
        }
        val now = System.currentTimeMillis()
        album.add(0, Word(key, info.title, info.enTitle.ifBlank { info.title }, photo, info.image, now, 0, now, 0, 0, 1))
        saveAlbum()
        return true
    }

    fun photoFile(w: Word): File? = if (w.photo.isBlank()) null else File(dir, w.photo).takeIf { it.exists() }

    fun dueWords(): List<Word> = album.filter { it.due <= System.currentTimeMillis() }
    fun reviewQueue(): List<Word> {
        val d = dueWords().shuffled()
        return if (d.isNotEmpty()) d.take(8) else album.sortedBy { it.box }.take(5)
    }
    fun review(key: String, ok: Boolean) {
        val i = album.indexOfFirst { it.key == key }
        if (i < 0) return
        val w = album[i]
        val nb = if (ok) minOf(4, w.box + 1) else 0
        album[i] = w.copy(box = nb, due = System.currentTimeMillis() + intervals[nb], right = w.right + if (ok) 1 else 0, wrong = w.wrong + if (ok) 0 else 1)
        saveAlbum()
    }

    // ---- مستويات الألعاب ----
    fun gameCount(g: String): Int { tick.value; return prefs.getInt("g_$g", 0) }
    fun level(g: String): Int = minOf(5, 1 + gameCount(g) / 5)
    /** إجابة صح: +1 نجمة. يرجّع true لو الطفل طلع مستوى (+3 نجوم) */
    fun correct(g: String): Boolean {
        val before = level(g)
        prefs.edit().putInt("g_$g", gameCount(g) + 1).apply()
        addStars(1)
        tick.value++
        val up = level(g) > before
        if (up) addStars(3)
        return up
    }
    fun missions(): Int { tick.value; return prefs.getInt("missions", 0) }
    fun missionDone() { prefs.edit().putInt("missions", missions() + 1).apply(); tick.value++ }
}
