plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
// المفتاح بيتقرا من: متغير بيئة GEMINI_KEY، أو gradle.properties، أو local.properties (جنب gradlew)
val geminiKey: String = System.getenv("GEMINI_KEY")?.takeIf { it.isNotBlank() }
    ?: (project.findProperty("GEMINI_KEY") as String?)?.takeIf { it.isNotBlank() }
    ?: java.util.Properties().also { pr -> rootProject.file("local.properties").takeIf { it.exists() }?.inputStream()?.use { pr.load(it) } }.getProperty("GEMINI_KEY", "")
android {
    namespace = "com.seeandlearn"
    compileSdk = 34
    defaultConfig { applicationId = "com.seeandlearn"; minSdk = 24; targetSdk = 34; versionCode = 4; versionName = "1.3"
        buildConfigField("String", "GEMINI_KEY", "\"$geminiKey\"")
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; buildConfig = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("io.coil-kt:coil-compose:2.6.0")
    implementation("com.google.mlkit:image-labeling:17.0.9")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")
}
