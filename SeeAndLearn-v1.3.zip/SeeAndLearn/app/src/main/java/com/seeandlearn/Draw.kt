package com.seeandlearn

import android.graphics.Bitmap
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.hypot

/** خط واحد رسمه الطفل */
class Line(val pts: List<Offset>, val color: Color)

private val Ink = Color(0xFF222222)
private val Brushes = listOf(Ink, Color(0xFFE53935), Color(0xFF1E88E5), Color(0xFF43A047), Color(0xFFFDD835), Color(0xFFFB8C00), Color(0xFF8E24AA), Color(0xFFEC407A), Color(0xFF795548))
private val DefaultColors = listOf(Color(0xFFFF6B9D), Color(0xFFFF9F43), Color(0xFF1DD1A1), Color(0xFF54A0FF), Color(0xFF8E7CFF), Color(0xFFFECA57))

private fun pathOf(l: Line, close: Boolean = false): Path = Path().apply {
    l.pts.forEachIndexed { i, o -> if (i == 0) moveTo(o.x, o.y) else lineTo(o.x, o.y) }
    if (close) close()
}

private fun isClosed(l: Line): Boolean {
    if (l.pts.size < 12) return false
    val diag = hypot(l.pts.maxOf { it.x } - l.pts.minOf { it.x }, l.pts.maxOf { it.y } - l.pts.minOf { it.y })
    return diag > 80f && (l.pts.first() - l.pts.last()).getDistance() < diag * 0.3f
}

/** يرسم الخطوط أسود على أبيض علشان الذكاء الاصطناعي يشوف الشكل بوضوح */
private fun renderLines(lines: List<Line>, w: Int, h: Int): Bitmap {
    val scale = 512f / maxOf(w, h).coerceAtLeast(1)
    val bmp = Bitmap.createBitmap((w * scale).toInt().coerceAtLeast(1), (h * scale).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(bmp)
    c.drawColor(android.graphics.Color.WHITE)
    val p = android.graphics.Paint().apply {
        isAntiAlias = true; style = android.graphics.Paint.Style.STROKE; color = android.graphics.Color.BLACK
        strokeWidth = maxOf(5f, 12f * scale); strokeCap = android.graphics.Paint.Cap.ROUND; strokeJoin = android.graphics.Paint.Join.ROUND
    }
    lines.forEach { l ->
        val path = android.graphics.Path()
        l.pts.forEachIndexed { i, o -> if (i == 0) path.moveTo(o.x * scale, o.y * scale) else path.lineTo(o.x * scale, o.y * scale) }
        c.drawPath(path, p)
    }
    return bmp
}

/** لعبة: ارسم شخصية وهي بتتحرك وتتكلم وتتلوّن */
@Composable
fun DrawAliveScreen() {
    val lines = remember { mutableStateListOf<Line>() }
    var cur by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var brush by remember { mutableStateOf(Ink) }
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    var phase by remember { mutableStateOf(0) }          // 0 رسم • 1 بيفكّر • 2 الرسمة عايشة
    var what by remember { mutableStateOf("") }
    var sentence by remember { mutableStateOf("") }
    var targets by remember { mutableStateOf(DefaultColors) }
    var talking by remember { mutableStateOf(false) }
    val colorAnim = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()

    val inf = rememberInfiniteTransition(label = "alive")
    val bounce by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(650, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bounce")
    val wig by inf.animateFloat(-1f, 1f, infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Reverse), label = "wig")
    val talk by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(170), RepeatMode.Reverse), label = "talk")

    fun say() {
        scope.launch {
            Sfx.speak(sentence, true)
            talking = true
            delay(sentence.length * 85L + 1800)
            talking = false
        }
    }

    fun bringToLife() {
        if (lines.isEmpty() || boxSize.width == 0) return
        phase = 1
        scope.launch {
            val key = BuildConfig.GEMINI_KEY
            val r = if (key.isNotBlank()) Gemini.drawing(renderLines(lines.toList(), boxSize.width, boxSize.height), key) else null
            val n = Sfx.name.ifBlank { "يا بطل" }
            what = r?.what ?: "رسمة حلوة"
            sentence = r?.sentence ?: listOf("أنا عايشة دلوقتي! شكرًا يا $n إنك رسمتني!", "هييي! بقيت أتحرك وأتكلم، أنا مبسوطة قوي!", "رسمتني حلوة قوي يا $n! تعالى نلعب!").random()
            targets = r?.colors?.takeIf { it.size >= 2 } ?: DefaultColors
            colorAnim.snapTo(0f)
            phase = 2
            Store.addStars(1)
            launch { colorAnim.animateTo(1f, tween(2600, easing = LinearEasing)) }
            say()
        }
    }

    val bb: Rect? = remember(lines.size, phase) {
        if (lines.isEmpty()) null else {
            val all = lines.flatMap { it.pts }
            Rect(all.minOf { it.x }, all.minOf { it.y }, all.maxOf { it.x }.coerceAtLeast(all.minOf { it.x } + 40f), all.maxOf { it.y }.coerceAtLeast(all.minOf { it.y } + 40f))
        }
    }

    Column(Modifier.fillMaxSize()) {
        Banner("🖍️ رسمتي بتتحرّك", if (phase == 2) "شوف رسمتك بقت عايشة!" else "ارسم أي حاجة بإصبعك وأنا هخلّيها تتكلم وتتلوّن", Teal, Blue)
        if (phase == 2) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("دي $what! 🎉", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Purple)
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Color.White).padding(14.dp)) {
                    Text("💬 $sentence", fontSize = 18.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
            }
        } else Spacer(Modifier.height(10.dp))

        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp).clip(RoundedCornerShape(26.dp)).background(Color.White).onSizeChanged { boxSize = it }) {
            if (lines.isEmpty() && cur.isEmpty()) Text("✏️ ارسم هنا", fontSize = 22.sp, color = Color.LightGray, modifier = Modifier.align(Alignment.Center))
            Canvas(Modifier.fillMaxSize()
                .graphicsLayer {
                    if (phase == 2) {
                        translationY = -bounce * 36f; rotationZ = wig * 5f
                        scaleX = 1f + bounce * 0.05f; scaleY = 1f + bounce * 0.05f
                    }
                }
                .pointerInput(phase, brush) {
                    if (phase == 0) detectDragGestures(
                        onDragStart = { cur = listOf(it) },
                        onDrag = { ch, _ -> ch.consume(); cur = cur + ch.position },
                        onDragEnd = {
                            if (cur.isNotEmpty()) lines.add(Line(if (cur.size == 1) cur + (cur[0] + Offset(0.5f, 0.5f)) else cur, brush))
                            cur = emptyList()
                        },
                        onDragCancel = { cur = emptyList() }
                    )
                }) {
                val n = lines.size
                val stroke = Stroke(width = 12f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                fun tOf(i: Int) = if (phase == 2) ((colorAnim.value * (n + 1)) - i).coerceIn(0f, 1f) else 0f
                // تلوين المساحات المقفولة
                if (phase == 2) lines.forEachIndexed { i, l ->
                    if (isClosed(l)) drawPath(pathOf(l, true), targets[(i + 1) % targets.size].copy(alpha = 0.6f * tOf(i)))
                }
                lines.forEachIndexed { i, l ->
                    val c = if (phase == 2) lerp(l.color, targets[i % targets.size], tOf(i)) else l.color
                    drawPath(pathOf(l), c, style = stroke)
                }
                if (cur.isNotEmpty()) drawPath(pathOf(Line(cur, brush)), brush, style = stroke)
                // عيون وبوق الشخصية
                if (phase == 2 && bb != null) {
                    val w = bb.width; val h = bb.height
                    val r = (minOf(w, h) * 0.07f).coerceIn(9f, 28f)
                    val ey = bb.top + h * 0.38f
                    listOf(bb.center.x - w * 0.17f, bb.center.x + w * 0.17f).forEach { x ->
                        drawCircle(Color.White, r, Offset(x, ey))
                        drawCircle(Ink, r, Offset(x, ey), style = Stroke(3f))
                        drawCircle(Ink, r * 0.5f, Offset(x + wig * r * 0.25f, ey))
                    }
                    val mw = w * 0.2f
                    val mh = if (talking) 8f + talk * minOf(h * 0.1f, 34f) else 8f
                    drawOval(Color(0xFFD63031), Offset(bb.center.x - mw / 2, bb.top + h * 0.62f), Size(mw, mh))
                }
            }
        }

        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            when (phase) {
                0 -> {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Brushes.forEach { c ->
                            Box(Modifier.size(40.dp).clip(CircleShape).background(c).border(if (brush == c) 4.dp else 1.dp, if (brush == c) Purple else Color.LightGray, CircleShape).clickable { brush = c })
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        BigBtn("↩️", Orange, Modifier.weight(0.5f)) { if (lines.isNotEmpty()) lines.removeAt(lines.lastIndex) }
                        BigBtn("🗑️", Red, Modifier.weight(0.5f)) { lines.clear() }
                        BigBtn("✨ خلّيها تتحرّك", Green, Modifier.weight(2f)) { bringToLife() }
                    }
                }
                1 -> Text("🔍 بفكّر في رسمتك...", fontSize = 22.sp, color = Purple, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                else -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BigBtn("🔊 تاني", Blue, Modifier.weight(1f)) { say() }
                    BigBtn("🖍️ رسمة جديدة", Pink, Modifier.weight(1.4f)) { lines.clear(); cur = emptyList(); talking = false; phase = 0 }
                }
            }
        }
    }
}
