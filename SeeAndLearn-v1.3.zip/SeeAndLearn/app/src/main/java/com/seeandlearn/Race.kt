package com.seeandlearn

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class RaceTheme(val emoji: String, val ar: String, val en: String)

val RaceThemes = listOf(
    RaceTheme("🔴", "حاجات حمرا", "something red"),
    RaceTheme("🟢", "حاجات خضرا", "something green"),
    RaceTheme("🔵", "حاجات زرقا", "something blue"),
    RaceTheme("🟡", "حاجات صفرا", "something yellow"),
    RaceTheme("🍳", "أدوات مطبخ", "a kitchen utensil, kitchen appliance or piece of kitchenware"),
    RaceTheme("✏️", "أدوات مدرسية", "a school supply such as a pencil, pen, notebook, ruler, eraser or school bag"),
    RaceTheme("🛋️", "أثاث البيت", "a piece of furniture"),
    RaceTheme("🧹", "أدوات نظافة", "a cleaning item such as soap, a broom, a sponge or a toothbrush"),
    RaceTheme("🍎", "أكل وفواكه وخضار", "food, a fruit or a vegetable"),
    RaceTheme("🧸", "لعب", "a toy"),
    RaceTheme("👕", "هدوم", "a piece of clothing, a shoe or an accessory worn on the body"),
    RaceTheme("🌿", "نباتات", "a plant, flower or tree"),
    RaceTheme("🎵", "آلات موسيقية", "a musical instrument or a toy musical instrument"),
    RaceTheme("🚗", "مواصلات", "a vehicle or a toy vehicle")
)

/** صورة واحدة في السباق. status: 0 بتتفحص • 1 صح • 2 غلط • 3 اتصورت قبل كده • 4 معرفتش أتأكد */
class Shot(val bmp: Bitmap) {
    var status by mutableStateOf(0)
    var key by mutableStateOf("")
    var ar by mutableStateOf("")
}

private const val RACE_SECONDS = 60

/** سباق الكاميرا: ٦٠ ثانية، صوّر أكبر عدد من نوع معيّن والذكاء الاصطناعي يتأكد من كل صورة */
@Composable
fun RaceScreen() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("prefs", 0) }
    val scope = rememberCoroutineScope()
    val shots = remember { mutableStateListOf<Shot>() }
    var theme by remember { mutableStateOf<RaceTheme?>(null) }
    var phase by remember { mutableStateOf(0) }        // 0 اختيار • 1 عدّ تنازلي • 2 سباق • 3 تأكيد آخر الصور • 4 النتيجة
    var count by remember { mutableStateOf(3) }
    var left by remember { mutableStateOf(RACE_SECONDS) }
    var msg by remember { mutableStateOf("") }
    var record by remember { mutableStateOf(prefs.getInt("race_best", 0)) }
    var newRecord by remember { mutableStateOf(false) }
    var job by remember { mutableStateOf<Job?>(null) }
    val noKey = BuildConfig.GEMINI_KEY.isBlank()

    DisposableEffect(Unit) { onDispose { job?.cancel() } }

    fun score() = shots.count { it.status == 1 }

    fun verify(shot: Shot, th: RaceTheme) {
        scope.launch {
            val key = BuildConfig.GEMINI_KEY
            var r = Gemini.checkMission(shot.bmp, key, th.en)
            if (r.ok == null) r = Gemini.checkMission(shot.bmp, key, th.en)
            val nm = r.name
            when {
                r.ok == null -> shot.status = 4
                r.ok == true && nm != null -> {
                    val k = nm.lowercase()
                    if (shots.any { it !== shot && it.status == 1 && it.key == k }) { shot.status = 3; Sfx.wrong() }
                    else {
                        shot.key = k; shot.status = 1
                        Sfx.correct()
                        shot.ar = Wiki.arName(nm)
                        Wiki.info(nm)?.let { Store.saveWord(it, shot.bmp) }
                    }
                }
                else -> { shot.status = 2; Sfx.wrong() }
            }
        }
    }

    fun finish() {
        val s = score()
        if (s > 0) Store.addStars(s)
        newRecord = s > record
        if (newRecord) { record = s; prefs.edit().putInt("race_best", s).apply() }
        phase = 4
        Sfx.speak(if (s == 0) "حاول تاني يا ${Sfx.name.ifBlank { "بطل" }}!" else "برافو يا ${Sfx.name.ifBlank { "بطل" }}! جمعت $s ${if (s == 1) "حاجة" else "حاجات"}", true)
    }

    fun start(th: RaceTheme) {
        theme = th; shots.clear(); msg = ""; newRecord = false; left = RACE_SECONDS
        job?.cancel()
        job = scope.launch {
            phase = 1
            Sfx.speak("هات ${th.ar}", true)
            delay(1800)
            for (c in 3 downTo 1) { count = c; delay(800) }
            phase = 2
            Sfx.speak("يلا!", true)
            val t0 = System.currentTimeMillis()
            while (true) {
                delay(200)
                left = (RACE_SECONDS - (System.currentTimeMillis() - t0) / 1000).toInt().coerceAtLeast(0)
                if (left <= 0) break
            }
            phase = 3
            while (shots.any { it.status == 0 }) delay(200)
            finish()
        }
    }

    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { b ->
        if (b != null) {
            val th = theme
            if (phase == 2 && th != null) { val s = Shot(b); shots.add(s); msg = ""; verify(s, th) }
            else msg = "⏰ الوقت خلص قبل ما الصورة تتاخد!"
        }
    }

    Column(Modifier.fillMaxSize()) {
        Banner("📸 سباق الكاميرا", if (phase == 0) "${RACE_SECONDS} ثانية! صوّر أكبر عدد من النوع اللي تختاره" else "${theme?.emoji} ${theme?.ar}", Orange, Pink)
        when (phase) {
            0 -> {
                if (record > 0) Text("🏆 أحسن رقم ليك: $record", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Purple, modifier = Modifier.fillMaxWidth().padding(top = 10.dp), textAlign = TextAlign.Center)
                if (noKey) Text("⚠️ السباق محتاج مفتاح الذكاء الاصطناعي (GEMINI_KEY) علشان يتأكد من الصور.", fontSize = 14.sp, color = Red, modifier = Modifier.padding(14.dp))
                LazyVerticalGrid(GridCells.Fixed(2), contentPadding = PaddingValues(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    item {
                        Box(Modifier.aspectRatio(1.3f).clip(RoundedCornerShape(24.dp)).background(Purple).clickable { if (!noKey) start(RaceThemes.random()) }, contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("🎲", fontSize = 40.sp); Text("مفاجأة", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                    items(RaceThemes) { th ->
                        val c = Palette[RaceThemes.indexOf(th) % Palette.size]
                        Box(Modifier.aspectRatio(1.3f).clip(RoundedCornerShape(24.dp)).background(c).clickable { if (!noKey) start(th) }, contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(th.emoji, fontSize = 40.sp)
                                Text(th.ar, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                            }
                        }
                    }
                }
            }
            1 -> Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("🦉", fontSize = 72.sp)
                Text("هات ${theme?.ar}!", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Purple, textAlign = TextAlign.Center)
                Text("جاهز؟ هتصوّر بالكاميرا، وأنا هتأكد من كل صورة", fontSize = 16.sp, textAlign = TextAlign.Center)
                Text(if (count in 1..3) "$count" else "", fontSize = 110.sp, fontWeight = FontWeight.Bold, color = Orange)
            }
            2, 3 -> Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (phase == 2) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("⏱️ $left", fontSize = 44.sp, fontWeight = FontWeight.Bold, color = if (left <= 10) Red else Purple)
                        Text("✅ ${score()}", fontSize = 44.sp, fontWeight = FontWeight.Bold, color = Green)
                    }
                    LinearProgressIndicator(progress = { left / RACE_SECONDS.toFloat() }, Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp)), color = if (left <= 10) Red else Orange)
                    BigBtn("📷 صوّر!", Orange, Modifier.fillMaxWidth().height(90.dp)) { camera.launch(null) }
                } else {
                    Text("⏰ الوقت خلص!", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Red)
                    Text("🔍 بتأكد من آخر الصور...", fontSize = 20.sp, color = Purple, fontWeight = FontWeight.Bold)
                }
                if (msg.isNotBlank()) Text(msg, fontSize = 15.sp, color = Red, textAlign = TextAlign.Center)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    shots.reversed().forEach { s -> ShotThumb(s, 76) }
                }
            }
            else -> Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (newRecord) "🏆 رقم قياسي جديد!" else "🏁 خلص السباق", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Purple)
                        Text("${score()} من ${shots.size} صورة صح", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        if (score() > 0) Text("+${score()} ⭐ واتضافت الكلمات لألبومك", fontSize = 15.sp, color = Color.Gray)
                    }
                }
                LazyVerticalGrid(GridCells.Fixed(3), Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(shots.toList()) { s -> ShotThumb(s, 110) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BigBtn("🔁 سباق تاني", Green, Modifier.weight(1f)) { theme?.let { start(it) } }
                    BigBtn("🏠 غيّر النوع", Blue, Modifier.weight(1f)) { job?.cancel(); phase = 0 }
                }
            }
        }
    }
}

@Composable
private fun ShotThumb(s: Shot, size: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(size.dp).clip(RoundedCornerShape(16.dp)).background(Color.White)) {
            Image(s.bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            val (icon, bg) = when (s.status) {
                1 -> "✅" to Green; 2 -> "❌" to Red; 3 -> "🔁" to Orange; 4 -> "⚠️" to Color.Gray; else -> "⏳" to Purple
            }
            Box(Modifier.align(Alignment.BottomEnd).padding(4.dp).clip(RoundedCornerShape(10.dp)).background(bg.copy(alpha = 0.9f)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                Text(icon, fontSize = 14.sp)
            }
        }
        if (size > 90) Text(when (s.status) { 1 -> s.ar; 2 -> "مش المطلوب"; 3 -> "اتصورت قبل كده"; 4 -> "معرفتش أتأكد"; else -> "بتتفحص..." }, fontSize = 12.sp, maxLines = 1, textAlign = TextAlign.Center)
    }
}
