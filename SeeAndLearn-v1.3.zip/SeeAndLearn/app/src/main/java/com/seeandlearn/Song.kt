package com.seeandlearn

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.exp
import kotlin.math.sin

// سلم بنتاتوني (دو ري مي صول لا): أي نغمات تتركّب جنب بعض بتطلع حلوة
private val Freqs = floatArrayOf(261.63f, 293.66f, 329.63f, 392.00f, 440.00f, 523.25f, 587.33f, 659.25f)
private val NoteNames = listOf("دو", "ري", "مي", "صول", "لا", "دو", "ري", "مي")

private class Timbre(val kind: String, val p: Float = 0f)

private fun timbreOf(en: String): Timbre = when (en) {
    "Piano" -> Timbre("piano")
    "Guitar" -> Timbre("pluck", 0.996f)
    "Oud" -> Timbre("pluck", 0.994f)
    "Qanun (instrument)" -> Timbre("pluck", 0.998f)
    "Harp" -> Timbre("pluck", 0.9975f)
    "Violin" -> Timbre("bowed")
    "Ney", "Flute" -> Timbre("blow")
    "Trumpet" -> Timbre("brass")
    "Accordion", "Saxophone" -> Timbre("reed")
    "Xylophone" -> Timbre("mallet")
    "Darbuka", "Drum" -> Timbre("drum")
    "Tambourine" -> Timbre("jingle")
    else -> Timbre("piano")
}

/** مولّد أصوات آلات بسيط (بدون ملفات صوت): كل آلة ليها طريقة توليد مختلفة */
object Synth {
    private const val RATE = 22050
    private val cache = HashMap<String, ShortArray>()

    private fun gen(t: Timbre, f0: Float): ShortArray {
        val dur = when (t.kind) { "piano" -> 1.3f; "pluck" -> 1.1f; "bowed" -> 0.9f; "blow" -> 0.85f; "brass" -> 0.7f; "reed" -> 0.8f; "mallet" -> 0.6f; "drum" -> 0.4f; else -> 0.45f }
        val n = (RATE * dur).toInt()
        val x = FloatArray(n)
        val rnd = java.util.Random(7)
        val tp = (2 * Math.PI).toFloat()
        fun env(i: Int, att: Float, rel: Float): Float {
            val tt = i / RATE.toFloat()
            val a = if (tt < att) tt / att else 1f
            val r = if (tt > dur - rel) ((dur - tt) / rel).coerceAtLeast(0f) else 1f
            return a * r
        }
        when (t.kind) {
            "pluck" -> {
                val period = (RATE / f0).toInt().coerceAtLeast(2)
                val buf = FloatArray(period) { rnd.nextFloat() * 2 - 1 }
                var p = 0
                for (i in 0 until n) { x[i] = buf[p]; val nx = (p + 1) % period; buf[p] = (buf[p] + buf[nx]) * 0.5f * t.p; p = nx }
            }
            "piano" -> for (i in 0 until n) {
                val tt = i / RATE.toFloat()
                var s = 0f
                for (h in 1..6) s += (1f / h) * sin(tp * f0 * h * tt) * exp(-(2.5f + h * 1.5f) * tt)
                x[i] = s * (if (tt < 0.004f) tt / 0.004f else 1f)
            }
            "bowed" -> for (i in 0 until n) {
                val tt = i / RATE.toFloat()
                val vib = 0.35f * sin(tp * 5.5f * tt)
                var s = 0f
                for (h in 1..8) s += (1f / h) * sin(tp * f0 * h * tt + vib * h)
                x[i] = s * env(i, 0.08f, 0.15f)
            }
            "blow" -> for (i in 0 until n) {
                val tt = i / RATE.toFloat()
                val ph = tp * f0 * tt + 0.25f * sin(tp * 5f * tt)
                x[i] = (sin(ph) + 0.25f * sin(2 * ph) + 0.08f * sin(3 * ph) + 0.07f * (rnd.nextFloat() * 2 - 1)) * env(i, 0.06f, 0.15f)
            }
            "brass" -> for (i in 0 until n) {
                val tt = i / RATE.toFloat()
                var s = 0f
                for (h in 1..8) s += (if (h <= 4) 1.2f else 0.6f) * (1f / h) * sin(tp * f0 * h * tt)
                x[i] = s * env(i, 0.04f, 0.12f)
            }
            "reed" -> for (i in 0 until n) {
                val tt = i / RATE.toFloat()
                val vib = 0.2f * sin(tp * 5f * tt)
                var s = 0.3f * sin(tp * f0 * 2 * tt + vib)
                for (h in intArrayOf(1, 3, 5, 7)) s += (1f / h) * sin(tp * f0 * h * tt + vib * h)
                x[i] = s * env(i, 0.05f, 0.15f)
            }
            "mallet" -> for (i in 0 until n) {
                val tt = i / RATE.toFloat()
                x[i] = sin(tp * f0 * 2 * tt) * exp(-7f * tt) + 0.4f * sin(tp * f0 * 7.8f * tt) * exp(-14f * tt)
            }
            "drum" -> {
                var ph = 0f
                val base = f0 * 0.5f
                for (i in 0 until n) {
                    val tt = i / RATE.toFloat()
                    ph += tp * base * (1f + 1.5f * exp(-25f * tt)) / RATE
                    x[i] = sin(ph) * exp(-11f * tt) + 0.25f * (rnd.nextFloat() * 2 - 1) * exp(-45f * tt)
                }
            }
            else -> {   // دف
                var prev = 0f
                for (i in 0 until n) {
                    val tt = i / RATE.toFloat()
                    val nz = rnd.nextFloat() * 2 - 1
                    val hp = nz - prev; prev = nz
                    x[i] = hp * exp(-10f * tt) * (0.6f + 0.4f * sin(tp * 30f * tt)) + 0.4f * sin(tp * f0 * 8 * tt) * exp(-12f * tt)
                }
            }
        }
        var peak = 0f
        for (v in x) if (Math.abs(v) > peak) peak = Math.abs(v)
        val g = if (peak > 0f) 0.8f / peak else 1f
        val fade = RATE / 100
        return ShortArray(n) { i ->
            val f = if (i > n - fade) (n - i).toFloat() / fade else 1f
            (x[i] * g * f * 32767f).toInt().coerceIn(-32768, 32767).toShort()
        }
    }

    private fun buf(en: String, idx: Int): ShortArray = synchronized(cache) { cache.getOrPut("$en#$idx") { gen(timbreOf(en), Freqs[idx]) } }

    fun play(en: String, idx: Int) {
        try {
            val s = buf(en, idx)
            val at = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(s.size * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
            at.write(s, 0, s.size)
            at.play()
            Handler(Looper.getMainLooper()).postDelayed({ try { at.release() } catch (e: Exception) { } }, s.size * 1000L / RATE + 400)
        } catch (e: Exception) { }
    }
}

class SongNote(val idx: Int, val ai: Boolean, val gap: Long)

/** لعبة: اختار آلة، اعزف نغمات، والذكاء الاصطناعي يرد عليك ويكمّل اللحن */
@Composable
fun ComposeSongScreen() {
    val instruments = Catalog["🎵 آلات موسيقية"].orEmpty()
    var inst by remember { mutableStateOf<Pair<String, String>?>(null) }
    val song = remember { mutableStateListOf<SongNote>() }
    var lastTap by remember { mutableStateOf(0L) }
    var title by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var hl by remember { mutableStateOf(-1) }
    var hint by remember { mutableStateOf("") }
    var job by remember { mutableStateOf<Job?>(null) }
    val scope = rememberCoroutineScope()

    DisposableEffect(Unit) {
        Music.pause()
        onDispose { job?.cancel(); Music.resume() }
    }

    fun playNote(en: String, i: Int) { scope.launch(Dispatchers.Default) { Synth.play(en, i) } }

    fun playSong(en: String, from: Int, praise: Boolean) {
        job?.cancel()
        job = scope.launch {
            for (k in from until song.size) {
                if (k > from) delay(song[k].gap)
                hl = k
                playNote(en, song[k].idx)
            }
            delay(900); hl = -1
            if (praise) Sfx.speak("برافو يا ${Sfx.name.ifBlank { "بطل" }}! ألّفنا أغنية اسمها $title", true)
        }
    }

    fun reply(en: String) {
        val kid = song.filter { !it.ai }.map { it.idx }
        if (kid.size < 2) { hint = "اعزف كام نغمة الأول وبعدين اضغط 🤖"; return }
        hint = ""; busy = true
        scope.launch {
            val key = BuildConfig.GEMINI_KEY
            val r = if (key.isNotBlank()) Gemini.melodyReply(kid.takeLast(12), en, key) else null
            val notes = r?.first ?: (kid.take(4).map { (it + 2) % 8 } + listOf(4, 2, 0))
            title = r?.second ?: "لحني الحلو"
            val from = song.size
            notes.forEach { song.add(SongNote(it, true, 420)) }
            busy = false
            Store.addStars(1)
            playSong(en, from, true)
        }
    }

    val cur = inst
    if (cur == null) {
        Column(Modifier.fillMaxSize()) {
            Banner("🎼 ألّف أغنية", "اختار آلة وابدأ العزف", Purple, Pink)
            LazyVerticalGrid(GridCells.Fixed(3), contentPadding = PaddingValues(14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(instruments) { (en, ar) ->
                    val thumb by produceState<String?>(null, en) { value = Wiki.thumb(en) }
                    Card(Modifier.clickable { inst = en to ar; song.clear(); title = ""; hint = ""; lastTap = 0L; Sfx.speak("يلا نعزف على $ar") },
                        shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(4.dp)) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.fillMaxWidth().height(80.dp).background(Purple.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
                                if (thumb != null) WikiImage(thumb, Modifier.fillMaxSize(), ContentScale.Crop) else Text("🎵", fontSize = 32.sp)
                            }
                            Text(ar, fontSize = 15.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(8.dp), textAlign = TextAlign.Center)
                        }
                    }
                }
            }
        }
        return
    }

    val (en, ar) = cur
    Column(Modifier.fillMaxSize()) {
        Banner("🎼 ألّف أغنية", "بتعزف على: $ar", Purple, Pink)
        Column(Modifier.weight(1f).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (title.isNotBlank()) Text("🎵 أغنية: $title", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Purple, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            Box(Modifier.fillMaxWidth().height(70.dp).clip(RoundedCornerShape(20.dp)).background(Color.White).padding(horizontal = 10.dp), contentAlignment = Alignment.CenterStart) {
                if (song.isEmpty()) Text("دوس على الأزرار الملونة وابدأ ألّف لحنك! 🎶", fontSize = 15.sp, color = Color.Gray)
                else Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    song.forEachIndexed { k, n ->
                        Box(Modifier.size(if (k == hl) 46.dp else 38.dp).clip(CircleShape).background(Palette[n.idx % Palette.size])
                            .border(if (n.ai) 3.dp else 0.dp, if (n.ai) Purple else Color.Transparent, CircleShape), contentAlignment = Alignment.Center) {
                            Text(if (n.ai) "🤖" else NoteNames[n.idx], fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            if (hint.isNotBlank()) Text(hint, fontSize = 16.sp, color = Red, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            if (busy) Text("🤖 بألّف رد على لحنك...", fontSize = 18.sp, color = Purple, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            Spacer(Modifier.weight(1f))
            // الأزرار من الأسفل للأعلى بالترتيب الموسيقي (شمال لليمين)
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.Bottom) {
                    for (i in 0 until 8) {
                        Box(Modifier.weight(1f).height((120 + i * 12).dp).clip(RoundedCornerShape(16.dp)).background(Palette[i % Palette.size])
                            .clickable {
                                if (busy) return@clickable
                                val now = System.currentTimeMillis()
                                val gap = if (lastTap == 0L) 450L else (now - lastTap).coerceIn(200L, 900L)
                                lastTap = now
                                song.add(SongNote(i, false, gap))
                                playNote(en, i)
                            }, contentAlignment = Alignment.BottomCenter) {
                            Text(NoteNames[i], color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 10.dp))
                        }
                    }
                }
            }
        }
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigBtn("▶️ شغّل", Green, Modifier.weight(1f)) { if (song.isNotEmpty() && !busy) playSong(en, 0, false) }
                BigBtn("🤖 رد عليا", Purple, Modifier.weight(1.3f)) { if (!busy) reply(en) }
                BigBtn("🗑️", Red, Modifier.weight(0.5f)) { job?.cancel(); song.clear(); title = ""; hint = ""; hl = -1; lastTap = 0L }
            }
            BigBtn("🔄 غيّر الآلة", Blue, Modifier.fillMaxWidth()) { job?.cancel(); inst = null }
        }
    }
}
